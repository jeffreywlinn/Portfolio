package Helper;

import Model.Appointments;
import Model.Users;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;
import java.util.Locale;
import java.util.ResourceBundle;

/**This class helps organize the methods and lists used throughout the program.
 * Including the comboBox of times on the welcome page, the login attempts,
 * and user appointments.*/
public class ListManager {

    /**This is the method that will generate the list of times in the comboBoxes
     * for start and end times on the Welcome page*/
    public ObservableList<LocalTime> generateTimeList(LocalTime startTime, int iter) {

        ObservableList<LocalTime> timeList = FXCollections.observableArrayList();
        timeList.add(startTime);
        for (int i = 0; i < iter; i++) {
            startTime = startTime.plusMinutes(15);
            timeList.add(startTime);
        }
        return timeList;
    }

    /**This list holds the login attempts that are printed to the login_activity.txt file*/
    public static ObservableList<Users> loginUserList = FXCollections.observableArrayList();

    /**Gets all users from Database and adds to the loginUserList*/
    public static ObservableList<Users> getAllUsers() {
        try {
            String sql = "SELECT * FROM users;";
            PreparedStatement psL = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = psL.executeQuery();
            while (rs.next()) {
                int userID = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");
                String password = rs.getString("Password");
                Users U = new Users(userID, userName, password);
                loginUserList.add(U);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return loginUserList;
    }

    /**Gets all users from Database at login that match the attempted UserName and Password*/
    public static ObservableList<Users> getLoginUserList(String userName1, String password1) {

        loginUserList.clear();

        try {
            String sql = "SELECT * FROM users WHERE User_Name = ? AND Password = ?;";
            PreparedStatement psL = Helper.JDBC.getConnection().prepareStatement(sql);
            psL.setString(1, userName1);
            psL.setString(2, password1);
            psL.execute();
            ResultSet rs = psL.executeQuery();
            while (rs.next()) {
                int userID = rs.getInt("User_ID");
                String userName = rs.getString("User_Name");
                String password = rs.getString("Password");
                Users U = new Users(userID, userName, password);
                loginUserList.add(U);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return loginUserList;
    }

    /**This list holds the appointments depending on the User who is logging in*/
    public static ObservableList<Appointments> userAppointmentsList = FXCollections.observableArrayList();

    /**Gets the appointments from the database joined with the users, compares times in UTC,
     * and adds matches to the userAppointmentList*/
    public static ObservableList<Appointments> getUserAppointmentsList(String User_Name) {

        ZoneId userZone = ZoneId.systemDefault();
        Instant userUTC = DateTimeManager.convertUserToUTC(); //  UTC of user time (+5 from EST)
        LocalDateTime userUTCDateTime = LocalDateTime.ofInstant(userUTC,userZone);

        /**Validation for whether the user language will be French or English*/
        boolean French = false;
        boolean English = false;

        String userLocale = Locale.getDefault().toString();
        if(userLocale.equals("fr_FR")) { French = true; }
        else { English = true; }

        userAppointmentsList.clear();
/**Selects all appointments joined with users from database*/

try {
            String sql = "SELECT * FROM appointments JOIN users ON users.User_ID = appointments.User_ID WHERE users.User_Name = ?;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ps.setString(1, User_Name);
            ps.execute();

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String apptTitle = rs.getString("Title");
                String apptDesc = rs.getString("Description");
                String apptLocation = rs.getString("Location");
                String apptType = rs.getString("Type");
                LocalDateTime apptStart = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime apptEnd = rs.getTimestamp("End").toLocalDateTime();
                int CustomerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");
                String userName = rs.getString("User_Name");

                /**CONVERT APPTSTART TO UTC FOR COMPARISON
                EST ZoneID, ZoneDate, ZoneTime*/
                ZoneId estZone = ZoneId.of("America/New_York");
                LocalDate estZoneDate = apptStart.toLocalDate();
                LocalTime estZoneTime = apptStart.toLocalTime();
                LocalDateTime estLocalDateTime = LocalDateTime.of(estZoneDate, estZoneTime);

                /**Converting USER ZDT to UTC for storage in database*/
                ZonedDateTime estZDT = ZonedDateTime.of(estLocalDateTime, estZone);
                Instant apptToUTCInstant = estZDT.toInstant();
                LocalDateTime apptUTCTime = LocalDateTime.ofInstant(apptToUTCInstant, estZone);

                if ((userUTCDateTime.equals(apptUTCTime) ||
                        (userUTCDateTime.isBefore(apptUTCTime) && userUTCDateTime.isAfter(apptUTCTime.minusMinutes(15))) ||
                        (userUTCDateTime.equals(apptUTCTime.minusMinutes(15))))) {
                    /**appointment start is within 15 minutes*/
                    Appointments A = new Appointments(appointmentID, apptTitle, apptDesc, apptLocation, apptType, apptStart, apptEnd, CustomerID, userID, contactID, userName);
                    userAppointmentsList.add(A);

                    if (French) {
                        ResourceBundle rb = ResourceBundle.getBundle("Languages/Nat_fr_FR");
                        try {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle(rb.getString("AppointmentDialog"));
                            alert.setHeaderText(rb.getString("UpcomingAppointments"));
                            alert.setContentText((rb.getString("upcomingMessage\n") +
                                    (rb.getString("upcomingID") + A.getAppointmentID() +
                                            (rb.getString("upcomingDate")) + A.getStart().toLocalDate() +
                                            (rb.getString("upcomingTime")) + A.getStart().toLocalTime())));
                            alert.showAndWait();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    } else {
                        ResourceBundle rb = ResourceBundle.getBundle("Languages/Nat_en_US");
                        try {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle(rb.getString("AppointmentDialog"));
                            alert.setHeaderText(rb.getString("UpcomingAppointments"));
                            alert.setContentText((rb.getString("upcomingMessage") +
                                    (rb.getString("upcomingID") + A.getAppointmentID() +
                                            (rb.getString("upcomingDate")) + A.getStart().toLocalDate() +
                                                    (rb.getString("upcomingTime")) + A.getStart().toLocalTime())));
                            alert.showAndWait();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        if (userAppointmentsList.isEmpty()) {
            /**If list is empty, no appointments within 15 minutes*/
            if(French) {
                ResourceBundle rb = ResourceBundle.getBundle("Languages/Nat_fr_FR");
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle(rb.getString("AppointmentDialog"));
                alert.setHeaderText(rb.getString("UpcomingAppointments"));
                alert.setContentText(rb.getString("upcomingNone"));
                alert.showAndWait();
            } else {
                ResourceBundle rb = ResourceBundle.getBundle("Languages/Nat_en_US");
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle(rb.getString("AppointmentDialog"));
                alert.setHeaderText(rb.getString("UpcomingAppointments"));
                alert.setContentText(rb.getString("upcomingNone"));
                alert.showAndWait();
            }
        }
        return userAppointmentsList;
    }


    /**END OF LIST MANAGER CLASS*/
}