package Helper;

import Model.Appointments;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;
import java.time.ZoneId;
import java.util.TimeZone;

/**The DateTimeManager provides a list and method to Convert times, get Overlaps, and hold an Overlap list*/
public class DateTimeManager {
    /**This list holds the appointments that qualify as being overlapped*/
    public static ObservableList<Appointments> overlapList = FXCollections.observableArrayList();
    /**This method selects all Appointments from the database, then checks them against seven
     * conditions for potential overlap. If there is an overlap, that appointment is added to
     * the list, and an error is shown.*/
    public static ObservableList<Appointments> getOverlapList(int Appointment_ID, LocalDate startDate, LocalTime startTime, LocalTime endTime) {
        overlapList.clear();
        try {
            String sql = "SELECT * FROM appointments;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String apptTitle = rs.getString("Title");
                String apptDesc = rs.getString("Description");
                String apptLocation = rs.getString("Location");
                String apptType = rs.getString("Type");
                LocalDateTime apptStart = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime apptEnd = rs.getTimestamp("End").toLocalDateTime();
                int CustomerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");

                System.out.println(Appointment_ID + " " + appointmentID);
                boolean sameAppt = false;
                if (appointmentID == Appointment_ID) {
                    sameAppt = true;
                }
                //Overlap Conditions
                if ( (!sameAppt) && (startDate.isEqual(apptStart.toLocalDate())) && (
                        //#1
                                ((startTime.equals(apptStart.toLocalTime())) && ((endTime.equals(apptEnd.toLocalTime())))) ||
                        //#2
                                        (((startTime.equals(apptStart.toLocalTime()))) && ((endTime.isAfter(apptEnd.toLocalTime())))) ||
                        //#3
                                        (((startTime.equals(apptStart.toLocalTime()))) && ((endTime.isBefore(apptEnd.toLocalTime())))) ||
                        //#4
                                        (((startTime.isAfter(apptStart.toLocalTime()))) && ((endTime.isAfter(apptEnd.toLocalTime())))) ||
                        //#5
                                        (((startTime.isBefore(apptStart.toLocalTime()))) && ((endTime.isAfter(apptStart.toLocalTime())))
                                                && (endTime.isBefore(apptEnd.toLocalTime()))) ||
                        //#6
                                        (((startTime.isBefore(apptStart.toLocalTime()))) && ((endTime.isAfter(apptEnd.toLocalTime())))) ||
                        //#7
                                        (((startTime.isAfter(apptStart.toLocalTime()))) && ((endTime.isBefore(apptEnd.toLocalTime()))))
                ) ) {
                    Appointments A = new Appointments(appointmentID, apptTitle, apptDesc, apptLocation, apptType, apptStart, apptEnd, CustomerID, userID, contactID);
                    overlapList.add(A);

                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error Dialog");
                    alert.setHeaderText("Appointment Conflict");
                    alert.setContentText("Start and End Times conflict with an existing appointment");
                    alert.showAndWait();
                }
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return overlapList;
    }

    /**This method is used to convert the User local time to UTC time*/
    public static Instant convertUserToUTC() {

        //USER ZoneID, ZoneDate, ZoneTime
        ZoneId userZone = ZoneId.of(ZoneId.systemDefault().getId());
        LocalDate userZoneDate = LocalDate.now(userZone);
        LocalTime userZoneTime = LocalTime.now(userZone);
        LocalDateTime userLocalDateTime = LocalDateTime.of(userZoneDate, userZoneTime);

        //Converting USER ZDT to UTC for storage in database
        ZonedDateTime userZDT = ZonedDateTime.of(userLocalDateTime, userZone);
        Instant userToUTCInstant = userZDT.toInstant();

        return userToUTCInstant;
    }


/**END OF DATE TIME MANAGER*/

}

