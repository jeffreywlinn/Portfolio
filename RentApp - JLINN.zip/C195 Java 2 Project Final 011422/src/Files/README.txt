REQUIREMENT Section E:

Title: C195 Software 2 Java Project
Purpose: Appointment Scheduling GUI-based Application for global consulting organization
conducting business in multiple geographic locations and languages.

Author: Jeffrey Linn
Contact Info: jlinn19@wgu.edu
Application Version: 1.0
Date: 01/15/2022

IntelliJ IDEA version 2021.1.3 (Community Edition)
Java JDK version Java SE 11.0.13
Java FX version compatible with JDK 11 (JavaFX jdk-11.0.13)
MySQL Connector driver version with update number (mysql-connector-java-8.1.23)

Directions for how to run the program:
Launch the application and enter your user name and password in the text fields. Click enter.
Negative authentication will prompt for correct user name and password.
Positive authentication will alert if any appointments are within 15 minutes.
All login attempts are logged to the "login_activity.txt" file.


FILTER APPOINTMENT TABLE: click the radio buttons to filter the Appointment table by All, Current Month, or Current Week.
MODIFY APPOINTMENT: select an appointment from the table, click Modify, edit the text fields/boxes, click save.
ADD APPOINTMENT: click clear, enter new information into fields/boxes, click save.
DELETE APPOINTMENT: select an appointment from the table, click Delete.

MODIFY CUSTOMER: select a customer from the customer table, click Modify, edit the text fields/boxes, click save.
ADD CUSTOMER: click clear, enter new information into all fields/boxes, click save.
DELETE CUSTOMER: Note(all associated appointments must be deleted prior to deleting customer). Select a customer
from the customer table, click Delete.

REPORTS: click the Reports button on the Welcome page to go to the Reports Page.
MONTH/TYPE REPORT: Select a Month and Type from the comboBoxes, then click Calculate. The box will show
how many appointments of that type are in that month.
APPOINTMENTS BY CONTACT: Select a contact from the comboBox to filter the appointment table. It will show
all the appointments with that contact.

Description of the additional report in part A.3.f:
On the Reports page, select the third comboBox to choose a CustomerID. This will calculate the number
of appointments that particular customer has in total.

LOG OUT: on the Welcome page, click the Log Out button to go to the Log In page.
EXIT: this button will disconnect from the database and close the program.
BACK: this button will take you from the Reports page to the Welcome page.

Lambda #1 is on Line 188 of reportsController
Lambda #2 is on Line 105 of loginController