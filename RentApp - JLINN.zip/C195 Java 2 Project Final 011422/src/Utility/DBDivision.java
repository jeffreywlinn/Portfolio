package Utility;

import Model.Division;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBDivision {

    private int divisionID;
    private String divisionName;
    private int countryID;

    /**List to hold all Divisions from database
     * Method to get all Divisions from database and add to list*/
    public static ObservableList<Division> allDivisions = FXCollections.observableArrayList();
    public static ObservableList<Division> getAllDivisions() {
        allDivisions.clear();

        try { String sql = "SELECT * FROM first_level_divisions;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int countryID = rs.getInt("Country_ID");
                Division D = new Division(divisionID, divisionName, countryID);
                allDivisions.add(D);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return allDivisions;
    }

    /**List to hold only divisions with CountryID = 1
     * Method to retrieve those divisions and add to list*/
    public static ObservableList<Division> division1 = FXCollections.observableArrayList();
    public static ObservableList<Division> getDivision1() {

        division1.clear();

        try { String sql = "SELECT * FROM first_level_divisions WHERE Country_ID = 1;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int countryID = rs.getInt("Country_ID");
                Division D = new Division(divisionID, divisionName, countryID);
                division1.add(D);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return division1;
    }

    /**List to hold only divisions with CountryID = 2
     * Method to retrieve those divisions and add to list*/
    public static ObservableList<Division> division2 = FXCollections.observableArrayList();
    public static ObservableList<Division> getDivision2() {

        division2.clear();

        try { String sql = "SELECT * FROM first_level_divisions WHERE Country_ID = 2;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int countryID = rs.getInt("Country_ID");
                Division D = new Division(divisionID, divisionName, countryID);
                division2.add(D);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return division2;
    }

    /**List to hold only divisions with CountryID = 3
     * Method to retrieve those divisions and add to list*/
    public static ObservableList<Division> division3 = FXCollections.observableArrayList();
    public static ObservableList<Division> getDivision3() {

        division3.clear();
        try { String sql = "SELECT * FROM first_level_divisions WHERE Country_ID = 3;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int divisionID = rs.getInt("Division_ID");
                String divisionName = rs.getString("Division");
                int countryID = rs.getInt("Country_ID");
                Division D = new Division(divisionID, divisionName, countryID);
                division3.add(D);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return division3;
    }





    /**END OF DBDIVISION CLASS*/
}

