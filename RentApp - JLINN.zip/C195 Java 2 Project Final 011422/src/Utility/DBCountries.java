package Utility;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import Model.Countries;
import java.sql.*;

public class DBCountries {

    private int countryID;
    private String countryName;
    private String location;

    /**List to hold all countries from Database
     * Method to retrieve all countries from Database and add to list.*/
    public static ObservableList<Countries> allCountries = FXCollections.observableArrayList();
    public static ObservableList<Countries> getAllCountries() {

        allCountries.clear();
        try {
            String sql = "SELECT * from countries";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int countryID = rs.getInt("Country_ID");
                String countryName = rs.getString("Country");
                Countries C = new Countries(countryID, countryName);
                allCountries.add(C);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return allCountries;
    }

    public  Object getLocation() {
        return location;
    }


/**END OF CLASS DBCOUNTRIES CLASS*/
}

