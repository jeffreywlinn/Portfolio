package Utility;

import Model.Contacts;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBContacts {

    private int contactID;
    private String contactName;
    private String contactEmail;

    /**List to hold all Contacts from database.
     * Method to retrieve all Contacts from database and add to list.*/
    public static ObservableList<Contacts> allContactsList = FXCollections.observableArrayList();
    public static ObservableList<Contacts> getAllContacts() {
        allContactsList.clear();

        try { String sql = "SELECT * FROM contacts";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int contactID = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");
                String contactEmail = rs.getString("Email");
                Contacts c = new Contacts(contactID, contactName, contactEmail);
                allContactsList.add(c);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return allContactsList;
    }

    /**List to hold all Contacts for the Reports page.
     * Method to retrieve all Contacts from database and add to list.*/
    public static ObservableList<Contacts> reportAllContactsList = FXCollections.observableArrayList();
    public static ObservableList<Contacts> getReportAllContactsList() {

        reportAllContactsList.clear();
        try { String sql = "SELECT * FROM contacts";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int contactID = rs.getInt("Contact_ID");
                String contactName = rs.getString("Contact_Name");
                String contactEmail = rs.getString("Email");
                Contacts c = new Contacts(contactID, contactName, contactEmail);
                reportAllContactsList.add(c);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return reportAllContactsList;
    }




/**END OF DB CONTACTS CLASS*/
}

