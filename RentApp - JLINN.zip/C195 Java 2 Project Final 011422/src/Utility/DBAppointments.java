package Utility;

import Model.Appointments;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.WeekFields;
public class DBAppointments {


    /********************************************************************************************************/

    /**APPOINTMENT LISTS FOR RADIO BUTTONS TO FILTER APPOINTMENT TABLE*/

    /**This is used for the radio button filter for appointments view all*/
    public static ObservableList<Appointments> allAppointmentsList = FXCollections.observableArrayList();
    public static ObservableList<Appointments> getAllAppointmentsList() {

        allAppointmentsList.clear();

        try { String sql = "SELECT * FROM appointments;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String apptTitle = rs.getString("Title");
                String apptDesc = rs.getString("Description");
                String apptLocation = rs.getString("Location");
                String apptType = rs.getString("Type");
                LocalDateTime apptStart = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime apptEnd = rs.getTimestamp("End").toLocalDateTime();
                int CustomerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");

                Appointments A = new Appointments(appointmentID, apptTitle, apptDesc, apptLocation, apptType, apptStart, apptEnd, CustomerID, userID, contactID);
                allAppointmentsList.add(A);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return allAppointmentsList;
    }

    /**This is used for the radio button filter for appointments by month*/
    public static ObservableList<Appointments> monthAppointmentsList = FXCollections.observableArrayList();
    public static ObservableList<Appointments> getMonthAppointmentsList() {

        monthAppointmentsList.clear();
        int currentMonth = (LocalDateTime.now().getMonthValue());
        try { String sql = "SELECT * FROM appointments;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String apptTitle = rs.getString("Title");
                String apptDesc = rs.getString("Description");
                String apptLocation = rs.getString("Location");
                String apptType = rs.getString("Type");
                LocalDateTime apptStart = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime apptEnd = rs.getTimestamp("End").toLocalDateTime();
                int CustomerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");

                if (apptStart.getMonthValue() == currentMonth) {
                    Appointments A = new Appointments(appointmentID, apptTitle, apptDesc, apptLocation, apptType, apptStart, apptEnd, CustomerID, userID, contactID);
                    monthAppointmentsList.add(A);
                }
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return monthAppointmentsList;
    }

    /**This is used for the radio button filter for appointments by week*/
    public static ObservableList<Appointments> weekAppointmentsList = FXCollections.observableArrayList();
    public static ObservableList<Appointments> getWeekAppts() {
        weekAppointmentsList.clear();

        try { String sql = "SELECT * FROM appointments;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);

            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String apptTitle = rs.getString("Title");
                String apptDesc = rs.getString("Description");
                String apptLocation = rs.getString("Location");
                String apptType = rs.getString("Type");
                LocalDateTime apptStart = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime apptEnd = rs.getTimestamp("End").toLocalDateTime();
                int CustomerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");

                // This is the week of the appointment
                int apptWeek = apptStart.get(WeekFields.SUNDAY_START.weekOfWeekBasedYear());
                //This is the current week of the year
                int thisWeek = LocalDate.now().get((WeekFields.SUNDAY_START.weekOfWeekBasedYear()));

                if (apptWeek == thisWeek) {
                    Appointments W = new Appointments(appointmentID, apptTitle, apptDesc, apptLocation, apptType, apptStart, apptEnd, CustomerID, userID, contactID);
                    weekAppointmentsList.add(W);
                }
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return weekAppointmentsList;
    }

    /********************************************************************************************************/

    /**REPORTS PAGE: ALL TYPES & SELECTED TYPES*/
    /**This is used to initialize the reports Type comboBox*/
    public static ObservableList<Appointments> allTypesList = FXCollections.observableArrayList();
    public static ObservableList<Appointments> getAllTypesList() {
        allTypesList.clear();
        try { String sql = "SELECT Type FROM appointments;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                String apptType = rs.getString("Type");
                Appointments A = new Appointments(apptType);
                allTypesList.add(A);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return allTypesList;
    }


    /********************************************************************************************************/

    /**Method to create a new Appointment*/
    public static void CREATEappt(String Title, String Description, String Location, String Type, LocalDate Start, LocalDate End, LocalTime startTime, LocalTime endTime, int Customer_ID, int User_ID, int Contact_ID) {
        try {
            String sqlC = "INSERT INTO appointments\n" +
                    "(Appointment_ID, Title, Description, Location, Type, Start, End, Customer_ID, User_ID, Contact_ID)\n" +
                    "VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            PreparedStatement psC = Helper.JDBC.getConnection().prepareStatement(sqlC, Statement.RETURN_GENERATED_KEYS);

            psC.setString(1, Title);
            psC.setString(2, Description);
            psC.setString(3, Location);
            psC.setString(4, Type);
            psC.setTimestamp(5, Timestamp.valueOf(LocalDateTime.of(Start, startTime)));
            psC.setTimestamp(6, Timestamp.valueOf(LocalDateTime.of(End, endTime)));
            psC.setInt(7, Customer_ID);
            psC.setInt(8, User_ID);
            psC.setInt(9, Contact_ID);
            psC.execute();

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        getAllAppointmentsList();
    }

    /**Method to update an existing Appointment*/
    public static void UPDATEappt(int Appointment_ID, String Title, String Description, String Location, String Type, LocalDate Start, LocalDate End, LocalTime startTime, LocalTime endTime, int Customer_ID, int User_ID, int Contact_ID) {
        try {
            String sqlC = "UPDATE appointments \n" +
                    "SET Appointment_ID = ?, Title = ?, Description = ?, Location = ?, Type = ?, Start = ?, End = ?, Customer_ID = ?, User_ID = ?, Contact_ID = ?\n" +
                    "WHERE Appointment_ID = ?;";
            PreparedStatement psC = Helper.JDBC.getConnection().prepareStatement(sqlC);
            psC.setInt(1, Appointment_ID);
            psC.setString(2, Title);
            psC.setString(3, Description);
            psC.setString(4, Location);
            psC.setString(5, Type);
            psC.setTimestamp(6, Timestamp.valueOf(LocalDateTime.of(Start, startTime)));
            psC.setTimestamp(7, Timestamp.valueOf(LocalDateTime.of(End, endTime)));
            psC.setInt(8, Customer_ID);
            psC.setInt(9, User_ID);
            psC.setInt(10, Contact_ID);
            psC.setInt(11, Appointment_ID);
            psC.execute();

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        getAllAppointmentsList();
    }

    /**Method to delete an appointment*/
    public static void DELETEappt(int appointmentID) {
        try {
            String sqlC = "DELETE FROM appointments WHERE Appointment_ID = ?;";
            PreparedStatement psDC = Helper.JDBC.getConnection().prepareStatement(sqlC);
            psDC.setInt(1, appointmentID);
            psDC.execute();

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        getAllAppointmentsList();
    }



/**END OF DB APPOINTMENTS CLASS*/
}






