package Utility;

import Model.Customers;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBCustomers {

    /**List to hold all customers from database.
     * Method to retrieve all Customers from database and add to list.*/
    public static ObservableList<Customers> allCustomersList = FXCollections.observableArrayList();
    public static ObservableList<Customers> getAllCustomersList() {

        allCustomersList.clear();

        try { String sql = "SELECT Customer_ID, Customer_Name, Address, Postal_Code, Phone, customers.Division_ID, first_level_divisions.Division_ID, countries.Country_ID, countries.Country\n" +
                "FROM customers \n" +
                "JOIN first_level_divisions \n" +
                "ON customers.Division_ID = first_level_divisions.Division_ID\n" +
                "JOIN countries\n" +
                "ON countries.Country_ID = first_level_divisions.Country_ID;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int customerID = rs.getInt("Customer_ID");
                String customerName = rs.getString("Customer_Name");
                String customerAddress = rs.getString("Address");
                String customerZip = rs.getString("Postal_Code");
                String customerPhone = rs.getString("Phone");
                int customerDivisionID = rs.getInt("Division_ID");
                int customerCountryID = rs.getInt("Country_ID");
                String customerCountry = rs.getString("Country");

                Customers C = new Customers(customerID, customerName, customerAddress, customerZip, customerPhone, customerDivisionID, customerCountryID, customerCountry);
                allCustomersList.add(C);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return allCustomersList;
    }

    /**Method to Create a new customer in the database*/
    public static void CREATEcustomer(String Customer_Name, String Address, String Postal_Code, String Phone, int Division_ID)  {
        try {
            String sqlC = "INSERT INTO customers (Customer_ID, Customer_Name, Address, Postal_Code, Phone, Division_ID) VALUES (NULL, ?, ?, ?, ?, ?);";
            PreparedStatement psC = Helper.JDBC.getConnection().prepareStatement(sqlC, Statement.RETURN_GENERATED_KEYS);

            psC.setString(1, Customer_Name);
            psC.setString(2, Address);
            psC.setString(3, Postal_Code);
            psC.setString(4, Phone);
            psC.setInt(5, Division_ID);

            psC.execute();

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        getAllCustomersList();
    }

    /**Method to Update a customer in the database.*/
    public static void UPDATEcustomer(int Customer_ID, String Customer_Name, String Address, String Postal_Code, String Phone, int Division_ID) {
        try {
            String sqlC = "UPDATE customers \n" +
                    "SET Customer_ID = ?, Customer_Name = ?, Address = ?, Postal_Code = ?, Phone = ?, Division_ID = ?\n" +
                    "WHERE Customer_ID = ?;";
            PreparedStatement psC = Helper.JDBC.getConnection().prepareStatement(sqlC);
            psC.setInt(1, Customer_ID);
            psC.setString(2, Customer_Name);
            psC.setString(3, Address);
            psC.setString(4, Postal_Code);
            psC.setString(5, Phone);
            psC.setInt(6, Division_ID);
            psC.setInt(7, Customer_ID);
            psC.execute();

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        getAllCustomersList();
    }

    /**Method to delete a customer from the database.*/
    public static void DELETEcustomer(int Customer_ID) {
        try {
            String sqlC = "DELETE FROM customers WHERE Customer_ID = ?;";
            PreparedStatement psDC = Helper.JDBC.getConnection().prepareStatement(sqlC);
            psDC.setInt(1, Customer_ID);
            psDC.execute();

        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        getAllCustomersList();
    }



    /** END OF DB CUSTOMERS CLASS*/
}

