package Model;

public class Customers {

    private int customerID;
    private String customerName;
    private String address;
    private String zip;
    private String phone;
    private int divisionID;
    private int customerCountryID;
    private String customerCountry;

    /**Constructor for Customers*/
    public Customers(int customerID, String customerName,
                     String address, String zip,
                     String phone, int divisionID, int customerCountryID, String customerCountry) {

        this.customerID = customerID;
        this.customerName = customerName;
        this.address = address;
        this.zip = zip;
        this.phone = phone;
        this.divisionID = divisionID;
        this.customerCountryID = customerCountryID;
        this.customerCountry = customerCountry;
    }

    /**Getter for Customer ID Number*/
    public  int getCustomerID() { return customerID; }

    /**Getter fro Customer Name*/
    public  String getCustomerName() {
        return customerName;
    }

    /**Getter for Customer Address*/
    public  String getAddress() {
        return address;
    }

    /**Getter for Customer Zip Code*/
    public  String getZip() {
        return zip;
    }

    /**Getter for Customer Phone*/
    public  String getPhone() {
        return phone;
    }

    /**Getter for Customer Division ID Number*/
    public  int getDivisionID() { return divisionID;}

    public String getCustomerCountry() { return customerCountry; }

    public int getCustomerCountryID() {
        return customerCountryID;
    }

    @Override
    public String toString() {
        return customerID + ": " + customerName;
    }

/**END OF CUSTOMER CLASS*/
}

