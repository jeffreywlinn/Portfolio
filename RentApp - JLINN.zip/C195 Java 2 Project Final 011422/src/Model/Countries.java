package Model;


public class Countries {

    private int countryID;
    private String countryName;

    /**Constructor for Countries class*/
    public Countries (int countryID, String countryName) {
        this.countryID = countryID;
        this.countryName = countryName;
    }

    /**Getter for CountryID*/
    public int getCountryID() { return countryID;}

    @Override
    public String toString() {
        return countryID + " : " + countryName;

    }

/**END OF COUNTRIES CLASS*/
}

