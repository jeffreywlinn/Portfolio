package Model;


public class Division {

    private int divisionID;
    private String divisionName;
    private int countryID;

    /**Constructor for Divisions*/
    public Division (int divisionID, String divisionName, int countryID) {
        this.divisionID = divisionID;
        this.divisionName = divisionName;
        this.countryID = countryID;
    }

    /**Getter for Division ID Number*/
    public int getDivisionID() { return divisionID;}

    /**Getter for Division country ID Number*/
    public int getCountryID() {return countryID;}

    @Override
    public String toString() {
        return divisionID + " : " + divisionName;
    }

/**END OF DIVISION CLASS*/
}

