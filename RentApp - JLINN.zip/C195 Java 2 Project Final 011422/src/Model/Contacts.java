package Model;

public class Contacts {

    private int contactID;
    private String contactName;
    private String contactEmail;

    /**Contacts constructor*/
    public Contacts(int contactID, String contactName, String contactEmail) {
        this.contactID = contactID;
        this.contactName = contactName;
        this.contactEmail = contactEmail;
    }

    /**Getter for Contact ID number*/
    public int getContactID() {
        return contactID;
    }

    @Override
    public String toString() {
        return contactID + " : " + contactName;
    }




    /**END OF CONTACTS CLASS*/
}

