package Model;

import java.time.LocalDateTime;

public class Appointments {

    private int appointmentID;
    private String apptTitle;
    private String apptDesc;
    private String apptLocation;
    private String apptType;
    private LocalDateTime apptStart;
    private LocalDateTime apptEnd;
    private int customerID;
    private int userID;
    private int contactID;
    private String userName;

    /**Constructor #1 for Appointments class. Basic for appointment table initializing.*/
    public Appointments(int appointmentID, String apptTitle, String apptDesc,
                        String apptLocation, String apptType,
                        LocalDateTime apptStart, LocalDateTime apptEnd, int customerID, int userID, int contactID) {

        this.appointmentID = appointmentID;
        this.apptTitle = apptTitle;
        this.apptDesc = apptDesc;
        this.apptLocation = apptLocation;
        this.apptType = apptType;
        this.apptStart = apptStart;
        this.apptEnd = apptEnd;
        this.customerID = customerID;
        this.userID = userID;
        this.contactID = contactID;

    }

    /**Constructor #2 for Appointments class. To set up filters by types.*/
    public Appointments(String apptType) {
        this.apptType = apptType;
    }

    /**Constructor #3 for Appointments class. To set up filters and validations by startTime*/
    public Appointments(LocalDateTime apptStart) {
        this.apptStart = apptStart;
    }

    /**Constructor #4 for Appointments class. To set up overlaps, filters and validations by start and end. */
    public Appointments(LocalDateTime apptStart, LocalDateTime apptEnd) {
        this.apptStart = apptStart;
        this.apptEnd = apptEnd;
    }

    /**Constructor #5 for Appointments class. To set up filters and validations by User*/
    public Appointments(int appointmentID, String apptTitle, String apptDesc, String apptLocation, String apptType, LocalDateTime apptStart, LocalDateTime apptEnd, int customerID, int userID, int contactID, String userName) {
        this.appointmentID = appointmentID;
        this.apptTitle = apptTitle;
        this.apptDesc = apptDesc;
        this.apptLocation = apptLocation;
        this.apptType = apptType;
        this.apptStart = apptStart;
        this.apptEnd = apptEnd;
        this.customerID = customerID;
        this.userID = userID;
        this.contactID = contactID;
        this.userName = userName;
    }

    /**Getter for Appointment ID number*/
    public int getAppointmentID() { return appointmentID; }

    /**Getter for Appointment Title*/
    public String getTitle() {
        return apptTitle;
    }

    /**Getter for Appointment Description*/
    public String getDescription() {
        return apptDesc;
    }

    /**Getter for Appointment Location*/
    public String getLocation() {
        return apptLocation;
    }

    /**Getter for Appointment Type*/
    public String getType() {
        return apptType;
    }

    /**Getter for Appointment Start Date*/
    public LocalDateTime getStart() {
        return apptStart;
    }

    /**Getter for Appointment End Date*/
    public LocalDateTime getEnd() {
        return apptEnd;
    }

    /**Getter for Appointment Customer ID Number*/
    public int getCustomerID() {
        return customerID;
    }

    /**Getter for Appointment User ID Number*/
    public int getUserID() {
        return userID;
    }

    /**Getter for Appointment Contact ID Number*/
    public int getContactID() {
        return contactID;
    }


    @Override
    public String toString() {
        return apptType;
    }



    /**END OF APPOINTMENTS CLASS*/
}

