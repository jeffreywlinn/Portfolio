package Model;

public class Users {

    private int userID;
    private String userName;
    private String password;

    /**Users constructor*/
    public Users(int userID, String userName, String password) {
        this.userID = userID;
        this.userName = userName;
        this.password = password;
    }

    /**Getter for User ID Number*/
    public int getUserID() { return userID;}

    @Override
    public String toString() {
        return  userID + ": " + userName;
    }

/**END OF USERS CLASS*/
}

