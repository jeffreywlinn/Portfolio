package Controllers;

import Helper.DateTimeManager;
import Helper.ListManager;
import Model.*;
import Utility.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.InputMethodEvent;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Optional;
import java.util.ResourceBundle;

/**This is the Welcome page controller that shows the Appointments Table
 * Allows Adding, Modifying, Saving, and Deleting Appointments*/
public class welcomeController implements Initializable {

    public Label welcomeTitle;

    /**This is the setup for the Customer tableView*/
    public TableView<Customers> allCustomersTable;
    public TableColumn<Customers, Integer> custIDCol;
    public TableColumn<Customers, String> custNameCol;
    public TableColumn<Customers, String> custAddressCol;
    public TableColumn<Customers, String> custZipCol;
    public TableColumn<Customers, String> custPhoneCol;
    public TableColumn<Customers, Integer> custDivIdCol;
    public TableColumn<Customers, Integer> custCountryIDCol;
    public TableColumn<Customers, String> custCountryCol;

    /**This is the setup for the Appointment tableView*/
    public TableView<Appointments> allApptsTable;
    public TableColumn<Appointments, Integer> apptIDCol;
    public TableColumn<Appointments, String> apptTitleCol;
    public TableColumn<Appointments, String> apptDescCol;
    public TableColumn<Appointments, String> apptLocationCol;
    public TableColumn<Appointments, String> apptTypeCol;
    public TableColumn<Appointments, LocalDateTime> apptStartCol;
    public TableColumn<Appointments, LocalDateTime> apptEndCol;
    public TableColumn<Appointments, Integer> apptCustIDCol;
    public TableColumn<Appointments, Integer> apptUserID;
    public TableColumn<Appointments, Integer> apptContactCol;

    /**These are all the buttons for the Welcome page*/
    public Button modifyApptButton;
    public Button deleteApptButton;
    public Button modCustButton;
    public Button deleteCustButton;
    public Button reportsButton;
    public Button onExitButton;
    public Button logOutButton;
    public Button clearApptButton;
    public Button clearCustButton;
    public Button saveApptButton;
    public Button saveCustButton;

    /**These are the radio buttons to filter the Appointment tableView*/
    public RadioButton viewAllRadio;
    public RadioButton byMonthRadio;
    public RadioButton byWeekRadio;
    public ToggleGroup viewToggleGroup;
    public TextField apptSearch;

    /**These are the Appointment text fields and date pickers for modifications*/
    public DatePicker startDate;
    public DatePicker endDate;
    public TextField wAppointmentID;
    public TextField wTitle;
    public TextField wDescription;
    public TextField wLocation;
    public TextField wType;

    /**These are the Customer textfields for modifications*/
    public TextField wcCustomerID;
    public TextField wcName;
    public TextField wcAddress;
    public TextField wcZip;
    public TextField wcPhone;

    /**These are all the comboBoxes for the Welcome page*/
    public ComboBox<Countries> countryCombo;
    public ComboBox<Division> divisionCombo;
    public ComboBox<Contacts> contactCombo;
    public ComboBox<Users> userCombo;
    public ComboBox<Customers> wCustomerID;
    public ComboBox timeStart;
    public ComboBox timeEnd;


    /**List used to prevent deleting a customer that has associated appointments*/
    public static ObservableList<Appointments> associatedAppointments = FXCollections.observableArrayList();


    /**This method will retrieve the appointments associated with the selected CustomerID
     * It connects with the database and puts all the matching appointments into the list.*/
    public ObservableList<Appointments> getAssociatedAppointments() {
        associatedAppointments.clear();
        try { String sql = "SELECT * FROM appointments WHERE Customer_ID = ?;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
            ps.setInt(1, allCustomersTable.getSelectionModel().getSelectedItem().getCustomerID());
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String apptTitle = rs.getString("Title");
                String apptDesc = rs.getString("Description");
                String apptLocation = rs.getString("Location");
                String apptType = rs.getString("Type");
                LocalDateTime apptStart = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime apptEnd = rs.getTimestamp("End").toLocalDateTime();
                int CustomerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");

                Appointments A = new Appointments(appointmentID, apptTitle, apptDesc, apptLocation, apptType, apptStart, apptEnd, CustomerID, userID, contactID);
                associatedAppointments.add(A);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return associatedAppointments;
    }

    /**Initialize all Appointments Table and Customers Table with data from the
     * Utility package classes methods for getting all Appointments and Customers
     * Then sets those lists to the tables*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /**These initialize the welcome page tables*/
        allApptsTable.setItems(DBAppointments.getAllAppointmentsList());
        allCustomersTable.setItems(DBCustomers.getAllCustomersList());

        apptIDCol.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        apptTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        apptDescCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        apptLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        apptContactCol.setCellValueFactory(new PropertyValueFactory<>("contactID"));
        apptTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        apptStartCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
        apptEndCol.setCellValueFactory(new PropertyValueFactory<>("End"));
        apptCustIDCol.setCellValueFactory(new PropertyValueFactory<>("CustomerID"));
        apptUserID.setCellValueFactory(new PropertyValueFactory<>("userID"));


        custIDCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        custNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        custAddressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        custZipCol.setCellValueFactory(new PropertyValueFactory<>("zip"));
        custPhoneCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        custDivIdCol.setCellValueFactory(new PropertyValueFactory<>("divisionID"));
        custCountryIDCol.setCellValueFactory(new PropertyValueFactory<>("customerCountryID"));
        custCountryCol.setCellValueFactory(new PropertyValueFactory<>("customerCountry"));

        /**initialize the combo boxes with all Countries, Contacts, Users, Customers.
         * Division comboBox is set to null*/
        countryCombo.setItems(DBCountries.getAllCountries());
        countryCombo.setValue(DBCountries.getAllCountries().stream().findFirst().get());
        divisionCombo.setItems(null);
        contactCombo.setItems(DBContacts.getAllContacts());
        userCombo.setItems(DBUsers.getAllUsers());
        wCustomerID.setItems(DBCustomers.getAllCustomersList());

        /**initialize the time boxes for selecting appointment times*/
        ListManager lm1 = new ListManager();
        timeStart.setItems(lm1.generateTimeList(LocalTime.of(0,0),95));
        timeStart.setValue("00:00");

        ListManager lm2 = new ListManager();
        ObservableList<LocalTime> endTimeList = lm2.generateTimeList(LocalTime.of(1,0), 91);
        endTimeList.add(LocalTime.of(23,59));
        timeEnd.setItems(endTimeList);
        timeEnd.setValue("00:00");

    }

    /************************************************************************************/

    /**Method sends the selected Customer table data to the text fields*/
    private void sendCustUpdate(Customers customer) {

        wcCustomerID.setText(String.valueOf(customer.getCustomerID()));
        wcPhone.setText(customer.getPhone());
        wcName.setText(customer.getCustomerName());
        wcAddress.setText(customer.getAddress());
        wcZip.setText(String.valueOf(customer.getZip()));

        divisionCombo.setItems(DBDivision.getAllDivisions());
        int divisionID = allCustomersTable.getSelectionModel().getSelectedItem().getDivisionID();
        for(Division DID : divisionCombo.getItems()) {
            if(DID.getDivisionID() == divisionID) {
                divisionCombo.setValue(DID);
                break;
            }
        }
        int CCID = divisionCombo.getSelectionModel().getSelectedItem().getCountryID();
        for(Countries selCountry : countryCombo.getItems()) {
            if (selCountry.getCountryID() == CCID) {
                countryCombo.setValue(selCountry);
                break;
            }
        }
        for(Division DID : divisionCombo.getItems()) {
            if(DID.getDivisionID() == divisionID) {
                divisionCombo.setValue(DID);
                break;
            }
        }
    }

    /**Method sends the selected Appointment table data to the text fields*/
    private void sendApptUpdate(Appointments appointment) {

        startDate.setValue(LocalDate.parse(String.valueOf(appointment.getStart().toLocalDate())));
        endDate.setValue(LocalDate.parse(String.valueOf(appointment.getEnd().toLocalDate())));
        timeStart.setValue(LocalTime.parse(String.valueOf(appointment.getStart().toLocalTime())));
        timeEnd.setValue(LocalTime.parse(String.valueOf(appointment.getEnd().toLocalTime())));
        wAppointmentID.setText(String.valueOf(appointment.getAppointmentID()));
        wDescription.setText(String.valueOf(appointment.getDescription()));
        wLocation.setText(String.valueOf(appointment.getLocation()));
        wType.setText(String.valueOf(appointment.getType()));
        wTitle.setText(String.valueOf(appointment.getTitle()));

        int comboCustomerID = allApptsTable.getSelectionModel().getSelectedItem().getCustomerID();
        for(Customers CID : wCustomerID.getItems()) {
            if(CID.getCustomerID() == comboCustomerID) {
                wCustomerID.setValue(CID);
                break;
            }
        }
        int comboContactID = allApptsTable.getSelectionModel().getSelectedItem().getContactID();
        for (Contacts CC : contactCombo.getItems()) {
            if (CC.getContactID() == comboContactID) {
                contactCombo.setValue(CC);
                break;
            }
        }
        int comboUserID = allApptsTable.getSelectionModel().getSelectedItem().getUserID();
        for (Users U : userCombo.getItems()) {
            if (U.getUserID() == comboUserID) {
                userCombo.setValue(U);
                break;
            }
        }
    }

    /************************************************************************************/
    /**TIME CHECKS.  These validate the appointment times for potential overlaps*/
    LocalTime earliestStart = LocalTime.parse("08:00"); //EST
    LocalTime latestStart = LocalTime.parse("21:45"); //EST
    LocalTime earliestEnd = LocalTime.parse("08:15"); //EST
    LocalTime latestEnd = LocalTime.parse("22:00"); //EST
    boolean timeCheck = false;

    /**Method uses the sendApptUpdate function to populate the Appointment text fields
     * if an appointment is selected.*/
    public void onModifyApptButton(ActionEvent actionEvent)  {
        if(!allApptsTable.getSelectionModel().isEmpty()) {
            sendApptUpdate(allApptsTable.getSelectionModel().getSelectedItem());
        }
    }

    /**Method will delete a selected appointment from the list
     * and ask for confirmation*/
    public void onDeleteApptButton(ActionEvent actionEvent) {

        int AID = allApptsTable.getSelectionModel().getSelectedItem().getAppointmentID();
        String AT = allApptsTable.getSelectionModel().getSelectedItem().getType();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Delete Appointment");
        alert.setContentText("Are you sure you want to delete/cancel this Appointment?\n" +
                "\nAppointment ID: " + AID + " : Type: " + AT + "\n");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            DBAppointments DA = new DBAppointments();
            DA.DELETEappt(allApptsTable.getSelectionModel().getSelectedItem().getAppointmentID());

            Alert alert2 = new Alert(Alert.AlertType.WARNING);
            alert2.setTitle("Confirmation Dialog");
            alert2.setHeaderText("Appointment Deleted");
            alert2.setContentText("Appointment has been deleted/canceled");
            alert2.showAndWait();
        } else {
            alert.close();
        }
    }

    /**Method will clear the appointment text fields and set
     * the comboBox values to null*/
    public void onClearAppt(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Cancel Update");
        alert.setContentText("Are you sure you want to cancel update?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){

            startDate.setValue(null);
            endDate.setValue(null);
            timeStart.setValue(null);
            timeEnd.setValue(null);
            wCustomerID.setValue(null);
            userCombo.setValue(null);
            contactCombo.setValue(null);
            wAppointmentID.clear();
            wTitle.clear();
            wDescription.clear();
            wLocation.clear();
            wType.clear();

        } else {
            alert.close();
        }
    }

    /**Button will commit the appointment to the list/database after
     * checking for overlaps with other appointments. If appointment ID is
     * empty, then new Appointment is created in database. Else, appointment
     * is Updated in database.*/
    public void onSaveAppt(ActionEvent actionEvent) {

        LocalTime selectedStart = LocalTime.parse(String.valueOf(timeStart.getValue())); //EST
        LocalTime selectedEnd = LocalTime.parse(String.valueOf(timeEnd.getValue())); //EST
        LocalDate date = startDate.getValue();

        // THIS WILL CREATE NEW APPOINTMENT
        if ((wAppointmentID.getText().isEmpty()) &&
                (!wTitle.getText().isEmpty()) &&
                (!wDescription.getText().isEmpty()) &&
                (!wLocation.getText().isEmpty()) &&
                (!wType.getText().isEmpty()) &&
                (startDate.getValue() != null) &&
                (startDate.getValue().equals(endDate.getValue())) &&
                (endDate.getValue() != null) &&
                (wCustomerID.getValue().getCustomerID() != 0) &&
                (userCombo.getSelectionModel().getSelectedItem().getUserID() != 0) &&
                (contactCombo.getSelectionModel().getSelectedItem().getContactID() != 0) &&
                (timeStart.getValue() != null) &&
                (timeEnd.getValue() != null) &&

                //Time Checks for the EST selected times
                (!selectedStart.isBefore(earliestStart)) &&
                (!selectedStart.isAfter(latestStart)) &&
                (selectedStart.isBefore(latestEnd)) &&
                (selectedStart.isBefore(selectedEnd)) &&
                (!selectedEnd.isAfter(latestEnd)) &&

                //Appointment Overlap Check
                (DateTimeManager.getOverlapList(Integer.parseInt("0"), date, selectedStart, selectedEnd).stream().count() == 0)

        ) {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Dialog");
            alert.setHeaderText("Add new Appointment");
            alert.setContentText("Are you sure you want to Add New Appointment?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){

                DBAppointments CC = new DBAppointments();
                CC.CREATEappt(
                        wTitle.getText(), wDescription.getText(), wLocation.getText(), wType.getText(),
                        startDate.getValue(), endDate.getValue(),
                        LocalTime.parse(timeStart.getSelectionModel().getSelectedItem().toString()),
                        LocalTime.parse(timeEnd.getSelectionModel().getSelectedItem().toString()),
                        wCustomerID.getSelectionModel().getSelectedItem().getCustomerID(),
                        userCombo.getSelectionModel().getSelectedItem().getUserID(),
                        contactCombo.getSelectionModel().getSelectedItem().getContactID());

                System.out.println("New Appointment Added");
            } else {
                alert.close();
            }

            //THIS WILL UPDATE THE APPOINTMENT
        } else if ((!wAppointmentID.getText().isEmpty()) &&
                (!wTitle.getText().isEmpty()) &&
                (!wDescription.getText().isEmpty()) &&
                (!wLocation.getText().isEmpty()) &&
                (!wType.getText().isEmpty()) &&
                (startDate.getValue() != null) &&
                (startDate.getValue().equals(endDate.getValue())) &&
                (endDate.getValue() != null) &&
                (wCustomerID.getValue() != null) &&
                (userCombo.getSelectionModel().getSelectedItem().getUserID() != 0) &&
                (contactCombo.getSelectionModel().getSelectedItem().getContactID() != 0) &&
                (timeStart.getValue() != null) &&
                (timeEnd.getValue() != null) &&

                //Time Checks for the EST selected times
                (!selectedStart.isBefore(earliestStart)) &&
                (!selectedStart.isAfter(latestStart)) &&
                (selectedStart.isBefore(latestEnd)) &&
                (selectedStart.isBefore(selectedEnd)) &&
                (!selectedEnd.isAfter(latestEnd)) &&

                //Appointment Overlap Check
                (DateTimeManager.getOverlapList(Integer.parseInt(wAppointmentID.getText()), date, selectedStart, selectedEnd).stream().count() == 0)
        ) {

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Dialog");
            alert.setHeaderText("Update Appointment?");
            alert.setContentText("Are you sure you want to Update Appointment?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                DBAppointments UA = new DBAppointments();
                UA.UPDATEappt(Integer.parseInt(wAppointmentID.getText()),
                        wTitle.getText(), wDescription.getText(), wLocation.getText(), wType.getText(),
                        startDate.getValue(), endDate.getValue(),
                        LocalTime.parse(timeStart.getSelectionModel().getSelectedItem().toString()),
                        LocalTime.parse(timeEnd.getSelectionModel().getSelectedItem().toString()),
                        wCustomerID.getSelectionModel().getSelectedItem().getCustomerID(),
                        userCombo.getSelectionModel().getSelectedItem().getUserID(),
                        contactCombo.getSelectionModel().getSelectedItem().getContactID());

                System.out.println("Appointment Updated");
            } else {
                alert.close();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Confirm Entries");
            alert.setContentText("1) Make sure all fields are complete. \n" +
                    "2) The earliest appointment start is 8:00AM EST. \n" +
                    "3) The latest appointment end is 10:00PM EST. \n" +
                    "4) Business hours are from 8:00AM to 10:00PM EST. \n" +
                    "5) End Time must be after Start Time.");
            alert.showAndWait();
        }
    }

    /************************************************************************************/

    /**Method uses the sendCustUpdate function to populate the Customer text fields*/
    public void onModCustButton(ActionEvent actionEvent) {

        /**This is setting the text fields for modification*/
        if (!allCustomersTable.getSelectionModel().isEmpty()) {
            sendCustUpdate(allCustomersTable.getSelectionModel().getSelectedItem());
        }
    }

    /**Method deletes a selected Customer from the database as long as there are no
     * associated appointments with the customer*/
    public void onDeleteCustButton(ActionEvent actionEvent) {
        /**YOU MUST FIRST DELETE ASSOCIATED APPOINTMENTS*/
        if (getAssociatedAppointments().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Dialog");
            alert.setHeaderText("Delete Customer");
            alert.setContentText("Are you sure you want to delete this Customer?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
                DBCustomers DC = new DBCustomers();
                DC.DELETEcustomer(allCustomersTable.getSelectionModel().getSelectedItem().getCustomerID());

                Alert alert2 = new Alert(Alert.AlertType.WARNING);
                alert2.setTitle("Warning Dialog");
                alert2.setHeaderText("Customer Deleted");
                alert2.setContentText("Customer has been deleted");
                alert2.showAndWait();

            } else {
                alert.close();
            }
        } else {
            Alert alert3 = new Alert(Alert.AlertType.ERROR);
            alert3.setTitle("ERROR Dialog");
            alert3.setHeaderText("Associated Appointments");
            alert3.setContentText("Associated Appointments must be deleted first.");
            alert3.showAndWait();
        }
    }

    /**Method will clear the Customer text fields*/
    public void onClearCust(ActionEvent actionEvent) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Cancel Update");
        alert.setContentText("Are you sure you want to cancel update?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){

            wcCustomerID.clear();
            wcName.clear();
            wcAddress.clear();
            wcZip.clear();
            wcPhone.clear();
            divisionCombo.setValue(null);

        } else {
            alert.close();
        }
    }

    /**Button will commit the customer to the list/database after asking for
     * confirmation. If customerID is empty, a new Customer is created in the
     * database. Else, customer is Updated in database.
     * */
    public void onSaveCust(ActionEvent actionEvent)  {

        //THIS WILL ADD THE CUSTOMER
        if(wcCustomerID.getText().isEmpty() &&
                !wcAddress.getText().isEmpty() &&
                !wcName.getText().isEmpty() &&
                !wcPhone.getText().isEmpty() &&
                !wcZip.getText().isEmpty() &&
                divisionCombo.getValue() != null &&
                countryCombo.getValue() != null
        ) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Dialog");
            alert.setHeaderText("Create new Customer");
            alert.setContentText("Are you sure you want to Create Customer?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
                DBCustomers CC = new DBCustomers();
                CC.CREATEcustomer(wcName.getText(),
                        wcAddress.getText(), wcZip.getText(), wcPhone.getText(),
                        divisionCombo.getSelectionModel().getSelectedItem().getDivisionID());
                System.out.println("New Customer Added");
            } else {
                alert.close();
            }
        } else if (!wcCustomerID.getText().isEmpty() &&
                !wcAddress.getText().isEmpty() &&
                !wcName.getText().isEmpty() &&
                !wcPhone.getText().isEmpty() &&
                !wcZip.getText().isEmpty() &&
                divisionCombo.getValue() != null &&
                countryCombo.getValue() != null
        ) {
            //THIS WILL UPDATE THE CUSTOMER
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Dialog");
            alert.setHeaderText("Update Customer");
            alert.setContentText("Are you sure you want to Update?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK){
                DBCustomers SC = new DBCustomers();
                SC.UPDATEcustomer(Integer.parseInt(wcCustomerID.getText()),
                        wcName.getText(), wcAddress.getText(), wcZip.getText(),
                        wcPhone.getText(), divisionCombo.getSelectionModel().getSelectedItem().getDivisionID());
                System.out.println("Customer Saved");
            } else {
                alert.close();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Confirm Entries");
            alert.setContentText("Make sure all fields are complete.");
            alert.showAndWait();
        }
    }

    /************************************************************************************/

    /**ComboBox to choose the country.
     * Depending on the selection, it will set the Division comboBox to only those
     * divisions in that selected country.*/
    public void onCountryCombo(ActionEvent actionEvent) throws NullPointerException{

        try {
            int CCID = countryCombo.getSelectionModel().getSelectedItem().getCountryID();
            if (CCID == 1) {
                divisionCombo.setItems(DBDivision.getDivision1());
            } else if (CCID == 2) {
                divisionCombo.setItems(DBDivision.getDivision2());
            } else if (CCID == 3) {
                divisionCombo.setItems(DBDivision.getDivision3());
            } else {
                divisionCombo.setItems(null);
            }
        } catch (NullPointerException N) {
        }
    }

    /**ComboBox to choose the first level division. No action*/
    public void onDivisionCombo(ActionEvent actionEvent) {
    }

    /************************************************************************************/

    /**Button will return the user to the Login page*/
    public void logOut(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load((getClass().getResource("/Views/Login.fxml")));
        Stage window = (Stage) logOutButton.getScene().getWindow();
        window.setScene(new Scene(root, 1200, 600));
        System.out.println("Logged Out");

        countryCombo.setValue(null);
    }

    /**Button will ask for confirmation to exit, close the program, and close connection.*/
    public void onExitButton(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Exit Program");
        alert.setContentText("Are you sure you want to exit?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.out.println("Closing connection...");
            Helper.JDBC.closeConnection();
            System.exit(0);
        } else {
            alert.close();
        }
    }

    /**Button goes to the Reports page*/
    public void onReportsButton(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load((getClass().getResource("/Views/reports.fxml")));
        Stage window = (Stage) reportsButton.getScene().getWindow();
        window.setScene(new Scene(root, 1200, 600));
    }

    /************************************************************************************/

    /**Selecting this radio button will show all Appointments from the database*/
    public void onViewAllRadio(ActionEvent actionEvent) {
        // This will return all appointments in the Appointments Table
        allApptsTable.setItems(DBAppointments.getAllAppointmentsList());
    }

    /**Selecting this radio button will show Appointments in the current Month*/
    public void onByMonthRadio(ActionEvent actionEvent) {
        // This will return the appointments in the current month in the Appointments Table
        allApptsTable.setItems(DBAppointments.getMonthAppointmentsList());
    }

    /**Selecting this radio button will show Appointments by Week*/
    public void onByWeekRadio(ActionEvent actionEvent) {
        // This will return the appointments in the current week
        allApptsTable.setItems(DBAppointments.getWeekAppts());
    }

    /************************************************************************************/

    /**This is an action event for the Time Start comboBox. When a time is select:
     * For the appointment time validation: cannot be outside 8:00AM to 10:00PM EST including weekends*/
    public void onTimeStart(ActionEvent actionEvent) {

        if (timeCheck = false) {
            Alert times = new Alert(Alert.AlertType.ERROR);
            times.setTitle("Error Dialog");
            times.setHeaderText("Appointment Time Conflict");
            times.setContentText("The earliest appointment start is 8:00AM EST. \n" +
                    "The latest appointment end is 10:00PM EST. \n" +
                    "Business hours are from 8:00AM to 10:00PM EST. \n" +
                    "End Time must be after Start Time.");
            times.showAndWait();
        }
    }
    /**This is an action event for the Time End comboBox. When a time is select:
     * For the appointment time validation: cannot be outside 8:00AM to 10:00PM EST including weekends*/
    public void onTimeEnd(ActionEvent actionEvent) {
        if(timeCheck = false) {
            Alert times = new Alert(Alert.AlertType.ERROR);
            times.setTitle("Error Dialog");
            times.setHeaderText("Appointment Time Conflict");
            times.setContentText("End Time must be after Start Time");
            times.showAndWait();
        }
    }



    public void onApptSearch(ActionEvent actionEvent) {

        String apptSearchText = apptSearch.getText();
        boolean errorTest = false;
        if (apptSearch.getText().trim().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Please Enter an Appointment Title or ID");
            alert.showAndWait();
            errorTest = true;
        }
        try {
            if (!apptSearch.getText().trim().isEmpty()) {
                for (Appointments apptID : DBAppointments.getAllAppointmentsList()) {
                    int apptEntryID = Integer.parseInt(apptSearchText);
                    if (apptID.getAppointmentID() == apptEntryID) {
                        allApptsTable.getSelectionModel().select(apptID);
                        System.out.println("Found Appointment ID");
                        errorTest = true;
                    }
                }
            }
        } catch (NumberFormatException e) {
            if (!apptSearch.getText().trim().isEmpty()) {
                for (Appointments apptTitle : DBAppointments.getAllAppointmentsList()) {
                    if (apptTitle.getTitle().contains(apptSearchText)) {
                        allApptsTable.getSelectionModel().select(apptTitle);
                        System.out.println("Found Appointment Title");
                        errorTest = true;
                    }
                }
            }
        }
        if (!errorTest) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Appointment Not Found");
            alert.showAndWait();
            System.out.println("Error. Appointment Not Found");
        }
    }

    public void onTextChange(InputMethodEvent inputMethodEvent) {
        String apptSearchText = apptSearch.getText();
        boolean errorTest = false;
        if (apptSearch.getText().trim().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Please Enter an Appointment Title or ID");
            alert.showAndWait();
            errorTest = true;
        }
        try {
            if (!apptSearch.getText().trim().isEmpty()) {
                for (Appointments apptID : DBAppointments.getAllAppointmentsList()) {
                    int apptEntryID = Integer.parseInt(apptSearchText);
                    if (apptID.getAppointmentID() == apptEntryID) {
                        allApptsTable.getSelectionModel().select(apptID);
                        System.out.println("Found Appointment ID");
                        errorTest = true;
                    }
                }
            }
        } catch (NumberFormatException e) {
            if (!apptSearch.getText().trim().isEmpty()) {
                for (Appointments apptTitle : DBAppointments.getAllAppointmentsList()) {
                    if (apptTitle.getTitle().contains(apptSearchText)) {
                        allApptsTable.getSelectionModel().select(apptTitle);
                        System.out.println("Found Appointment Title");
                        errorTest = true;
                    }
                }
            }
        }
        if (!errorTest) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Appointment Not Found");
            alert.showAndWait();
            System.out.println("Error. Appointment Not Found");
        }
    }


    /**END OF WELCOME CONTROLLER*/
}
