package Controllers;

import Helper.DateTimeManager;
import Helper.ListManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.function.Supplier;

public class loginController implements Initializable {

    public TextField userNameText;
    public TextField passwordText;
    public Label titleLogin;
    public Label userLocation;
    public Button signInButton;
    public Button onExitButton;
    public Label contentTitle;
    ResourceBundle rb;
    Stage stage;
    Parent scene;

    /**Initialize method gets the ZoneID and displays it on the form
    And sets the language based on the user locale */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        System.out.println("Initialized");
        Helper.JDBC.openConnection();
        System.out.println("Connection Open");
        System.out.println("User Locale: " + Locale.getDefault());

        if(Locale.getDefault().toString().equals("fr_FR")) {
            rb = ResourceBundle.getBundle("Languages/Nat_fr_FR");
            try {
                userLocation.setText(ZoneId.systemDefault().toString());
                userNameText.setText(rb.getString("UserName"));
                passwordText.setText(rb.getString("Password"));
                titleLogin.setText(rb.getString("Title"));
                signInButton.setText(rb.getString("SignInButton"));
                onExitButton.setText(rb.getString("ExitButton"));
                contentTitle.setText(rb.getString("contentTitle"));

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {  rb = ResourceBundle.getBundle("Languages/Nat_en_US");
            try {
                userLocation.setText(ZoneId.systemDefault().toString());
                userNameText.setText(rb.getString("UserName"));
                passwordText.setText(rb.getString("Password"));
                titleLogin.setText(rb.getString("Title"));
                signInButton.setText(rb.getString("SignInButton"));
                onExitButton.setText(rb.getString("ExitButton"));
                contentTitle.setText(rb.getString("contentTitle"));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
       /**LAMBDA #2 at Line 105 in SignIn action event Method
        * The sign in button will perform multiple functions and validations.
        * First, the login attempt is logged in the login_activity file.*/
    public void onSignInButton(ActionEvent actionEvent) throws IOException {
        /**This writes the login attempts to Files */
        FileWriter fwLogins = new FileWriter("src/Files/login_activity.txt", true);
        PrintWriter pwLogins = new PrintWriter(fwLogins);
        ListManager.getAllUsers();
        ListManager.getLoginUserList(userNameText.getText().trim(), passwordText.getText().trim());

        if (ListManager.loginUserList.stream().count() > 0) {

            System.out.println("Signing in...\n");

            /**Writing login attempts to File*/
            pwLogins.println("\n*****Login Attempt*****");
            pwLogins.println("UTC Time: " + DateTimeManager.convertUserToUTC());
            pwLogins.println("User Time: " + ZonedDateTime.now());
            pwLogins.println("Access Granted\n");
            pwLogins.close();

            /*Check upcoming appointments within 15 min of user time*/
            ListManager.getUserAppointmentsList(userNameText.getText());

            Parent root = FXMLLoader.load((getClass().getResource("/Views/Welcome.fxml")));
            Stage window = (Stage) signInButton.getScene().getWindow();
            window.setScene(new Scene(root, 1200, 600));

        } else { /*If access is denied, gets Locale language and shows alert in that language*/
            System.out.println("Access denied.");

            /**LAMBDA #2 */
            Supplier<String> nameSupplier = () -> userNameText.getText();
            Supplier<String> passSupplier = () -> passwordText.getText();

            /**Writing login attempts to File*/
            pwLogins.println("\n*****Login Attempt*****\nUser: " + nameSupplier.get() + "\nPW: " + passSupplier.get());
            pwLogins.println("UTC Time: " + DateTimeManager.convertUserToUTC());
            pwLogins.println("User Time: " + ZonedDateTime.now());
            pwLogins.println("Access denied.\n");
            pwLogins.close();

            /** If the locale is in French/France, the alert pulls from the Resource Bundle to translate
             * the error message into French*/
            if(Locale.getDefault().toString().equals("fr_FR")) {
                rb = ResourceBundle.getBundle("Languages/Nat_fr_FR");
                try {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle(rb.getString("Error"));
                    alert.setHeaderText(rb.getString("ErrorHeader"));
                    alert.setContentText(rb.getString("ErrorContent"));
                    alert.show();

                } catch (Exception e) {
                    e.printStackTrace();
                }
                /** If the locale is in English/US, the alert pulls from the Resource Bundle to translate
                 * the error message into English/US*/
            } else {  rb = ResourceBundle.getBundle("Languages/Nat_en_US");
                try {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle(rb.getString("Error"));
                    alert.setHeaderText(rb.getString("ErrorHeader"));
                    alert.setContentText(rb.getString("ErrorContent"));
                    alert.show();

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /** Exit button confirms program exit from user and closes connection */
    public void onExitButton(ActionEvent actionEvent) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Exit Program");
        alert.setContentText("Are you sure you want to exit?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            Helper.JDBC.closeConnection();
            System.exit(0);
        } else {
            alert.close();
        }
    }








    /**END OF LOGIN CONTROLLER */
}