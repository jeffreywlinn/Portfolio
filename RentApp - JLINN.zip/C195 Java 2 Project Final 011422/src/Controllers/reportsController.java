package Controllers;

import Model.Appointments;
import Model.Contacts;
import Model.Customers;
import Utility.DBAppointments;
import Utility.DBContacts;
import Utility.DBCustomers;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

/**This is the controller for the Reports page which will
 * perform the 3 required reports*/
public class reportsController implements Initializable {

    public Label Title;

    /**These are forming the Appointments table on the Reports Page*/
    public TableView<Appointments> reportApptTable;
    public TableColumn<Appointments, Integer> apptIDCol;
    public TableColumn<Appointments, String> apptTitleCol;
    public TableColumn<Appointments, String> apptDescCol;
    public TableColumn<Appointments, String> apptLocationCol;
    public TableColumn<Appointments, String> apptTypeCol;
    public TableColumn<Appointments, LocalDateTime> apptStartCol;
    public TableColumn<Appointments, LocalDateTime> apptEndCol;
    public TableColumn<Appointments, Integer> apptCustIDCol;
    public TableColumn<Appointments, Integer> apptUserID;
    public TableColumn<Appointments, Integer> apptContactCol;

    /** These are the Reports Page buttons*/
    public Button onExitButton;
    public Button backButton;
    public Button calculateButton;

    /** This is the 1st REPORT which accepts the comboBox selections of
     * Month + Type report calculation */
    public ComboBox<Appointments> reportTypeCombo;
    public ComboBox<Month> reportMonthCombo;
    public TextField monthTypeTotal;

    /** This is the 2nd REPORT comboBox which filters the Appointment Table
     * with appointments based on contact selection from the Contact comboBox*/
    public ComboBox<Contacts> reportContactCombo;

    /** This is for the 3rd Report: Appointments based on CustomerID selection
     * LAMBDA #1 ON LINE 188 */
    public ComboBox<Customers> reportCustIDCombo;
    public TextField customerIDTotal;

    public static ObservableList<Appointments> contactAppointmentList = DBAppointments.getAllAppointmentsList();
    public static ObservableList<Appointments> totalCalcList = FXCollections.observableArrayList();
    public static ObservableList<Appointments> customerAppointmentList = DBAppointments.getAllAppointmentsList();

    /** This initialize function for the Reports page will set up the Appointments table
     * comboBoxes, and buttons*/
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        /** This initializes the Reports Appointment Table to null */
        reportApptTable.setItems(null);

        apptIDCol.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        apptTitleCol.setCellValueFactory(new PropertyValueFactory<>("Title"));
        apptDescCol.setCellValueFactory(new PropertyValueFactory<>("Description"));
        apptLocationCol.setCellValueFactory(new PropertyValueFactory<>("Location"));
        apptContactCol.setCellValueFactory(new PropertyValueFactory<>("contactID"));
        apptTypeCol.setCellValueFactory(new PropertyValueFactory<>("Type"));
        apptStartCol.setCellValueFactory(new PropertyValueFactory<>("Start"));
        apptEndCol.setCellValueFactory(new PropertyValueFactory<>("End"));
        apptCustIDCol.setCellValueFactory(new PropertyValueFactory<>("CustomerID"));
        apptUserID.setCellValueFactory(new PropertyValueFactory<>("userID"));

        /** This sets the Month comboBox with the months of the year */
        reportMonthCombo.getItems().addAll(
                Month.valueOf("JANUARY"),
                Month.valueOf("FEBRUARY"),
                Month.valueOf("MARCH"),
                Month.valueOf("APRIL"),
                Month.valueOf("MAY"),
                Month.valueOf("JUNE"),
                Month.valueOf("JULY"),
                Month.valueOf("AUGUST"),
                Month.valueOf("SEPTEMBER"),
                Month.valueOf("OCTOBER"),
                Month.valueOf("NOVEMBER"),
                Month.valueOf("DECEMBER")
        );
        /**These set the comboBox items for types, contacts, and customers
         * And set the Contact value to the first on the list.
         * And set the Customer value to the first on the list.*/
        reportTypeCombo.setItems(DBAppointments.getAllTypesList());
        reportContactCombo.setItems(DBContacts.getReportAllContactsList());
        reportContactCombo.setValue(DBContacts.getReportAllContactsList().stream().findFirst().get());
        reportCustIDCombo.setItems(DBCustomers.getAllCustomersList());
        reportCustIDCombo.setValue(DBCustomers.getAllCustomersList().stream().findFirst().get());
    }

    /**ComboBox to select Month from Database, no other action*/
    public void onMonthCombo(ActionEvent actionEvent) {

    }

    /**ComboBox to select Type from Database, no other action*/
    public void onTypeCombo(ActionEvent actionEvent) {

    }

    /**When this is clicked, it counts all appointments that match the type and month selections.
     * Filters all appointments by the selected Month and selected Type, adds those matching
     * appointments to the totalCalcList and then counts the items in the list.*/
    public void onCalculate(ActionEvent actionEvent) {

        totalCalcList.clear();

        if ((reportTypeCombo.getSelectionModel().getSelectedItem()) != null && (reportMonthCombo.getSelectionModel().getSelectedItem() != null)) {
            try {
                String sql = "SELECT * FROM appointments WHERE Type = ? AND MONTH(Start) = ?;";
                PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);
                ps.setString(1, reportTypeCombo.getSelectionModel().getSelectedItem().getType());
                ps.setInt(2, (reportMonthCombo.getSelectionModel().getSelectedItem().getValue()));
                ps.execute();

                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    int appointmentID = rs.getInt("Appointment_ID");
                    String apptTitle = rs.getString("Title");
                    String apptDesc = rs.getString("Description");
                    String apptLocation = rs.getString("Location");
                    String apptType = rs.getString("Type");
                    LocalDateTime apptStart = rs.getTimestamp("Start").toLocalDateTime();
                    LocalDateTime apptEnd = rs.getTimestamp("End").toLocalDateTime();
                    int CustomerID = rs.getInt("Customer_ID");
                    int userID = rs.getInt("User_ID");
                    int contactID = rs.getInt("Contact_ID");

                    Appointments A = new Appointments(appointmentID, apptTitle, apptDesc, apptLocation, apptType, apptStart, apptEnd, CustomerID, userID, contactID);
                    totalCalcList.add(A);
                }
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
            monthTypeTotal.setText(String.valueOf(totalCalcList.stream().count()));
        }
    }

    /**On selecting a contact from the comboBox, all appointments are filtered for matching
     * appointments with that contact. Matching appointments are added to the
     * contactAppointmentList and the tableView is set with the items from that list.*/
    public void onContactCombo(ActionEvent actionEvent) throws NullPointerException{

        contactAppointmentList.clear();

        try { String sql = "SELECT * FROM appointments;";
            PreparedStatement ps = Helper.JDBC.getConnection().prepareStatement(sql);

            ps.execute();
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                int appointmentID = rs.getInt("Appointment_ID");
                String apptTitle = rs.getString("Title");
                String apptDesc = rs.getString("Description");
                String apptLocation = rs.getString("Location");
                String apptType = rs.getString("Type");
                LocalDateTime apptStart = rs.getTimestamp("Start").toLocalDateTime();
                LocalDateTime apptEnd = rs.getTimestamp("End").toLocalDateTime();
                int CustomerID = rs.getInt("Customer_ID");
                int userID = rs.getInt("User_ID");
                int contactID = rs.getInt("Contact_ID");

                if(reportContactCombo.getValue().getContactID() == contactID) {
                Appointments A = new Appointments(appointmentID, apptTitle, apptDesc, apptLocation, apptType, apptStart, apptEnd, CustomerID, userID, contactID);
                contactAppointmentList.add(A); }
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        } catch (NullPointerException N) {
        }
        reportApptTable.setItems(contactAppointmentList);
    }

    /**For Report #3. This comboBox is to select CustomerID and will show total appointments
     * for that Customer.  LAMBDA #1
     * The lambda function provides a much more efficient way to filter the list of appointments
     * and reduction in code volume, rather than having to repeat the method of getting all
     * appointments again.*/
    public void onCustIDCombo(ActionEvent actionEvent) throws NullPointerException{

        try {List<Appointments> customerAppointments = customerAppointmentList
                .stream()
                .filter(c -> c.getCustomerID() == reportCustIDCombo.getValue().getCustomerID() )
                .collect(Collectors.toList());
        customerIDTotal.setText(String.valueOf(customerAppointments.stream().count())
        );
        } catch (NullPointerException N){
        }
    }

    /**This button will take the user back to the Welcome page*/
    public void onBackButton(ActionEvent actionEvent) throws IOException {

        Parent root = FXMLLoader.load((getClass().getResource("/Views/Welcome.fxml")));
        Stage window = (Stage) backButton.getScene().getWindow();
        window.setScene(new Scene(root, 1200, 600));
    }

    /**This button will confirm exiting the program, close the program and connection*/
    public void onExitButton(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Exit Program");
        alert.setContentText("Are you sure you want to exit?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            Helper.JDBC.closeConnection();
            System.out.println("Closing connection...");
            System.exit(0);
        } else {
            alert.close();
        }
    }




    /**END OF REPORTS CONTROLLER*/
}
