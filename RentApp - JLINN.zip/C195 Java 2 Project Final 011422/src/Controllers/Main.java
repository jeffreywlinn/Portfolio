package Controllers;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.Locale;
import java.util.ResourceBundle;

public class Main extends Application {

    /** On program start the Login page will be loaded.
     * The Locale of the user will be determined and if the
     * landguage will be translated to either French or English.*/
    @Override
    public void start(Stage primaryStage) throws Exception{

        Parent root;
        FXMLLoader loader = new FXMLLoader((getClass().getResource("/Views/Login.fxml")));
        root = loader.load();
        if(Locale.getDefault().toString().equals("fr_FR")) {
            ResourceBundle rb = ResourceBundle.getBundle("Languages/Nat_fr_FR");
            primaryStage.setTitle(rb.getString("stageTitle"));
        } else {
            ResourceBundle rb = ResourceBundle.getBundle("Languages/Nat_en_US");
            primaryStage.setTitle(rb.getString("stageTitle"));
        }
        primaryStage.setScene(new Scene(root, 500, 400));
        primaryStage.show();
    }

    /**Main method to Launch*/
    public static void main(String[] args) {

        //Locale.setDefault(new Locale("fr", "FR"));


        launch(args);

    }





    /**END OF MAIN CLASS*/
}