package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.OutSourced;
import java.util.Optional;
import java.util.Random;
import java.net.URL;
import java.util.ResourceBundle;

public class addPartController implements Initializable {

    public TextField addPartIDTxt;
    public TextField addPartNameTxt;
    public TextField addPartInvTxt;
    public TextField addPartPriceTxt;
    public TextField addPartMaxTxt;
    public TextField addPartMinTxt;
    public ToggleGroup AddPartGroup;
    public Button saveAddPart;
    public Button cancelAddPart;
    public RadioButton radioPartInHouse;
    public RadioButton radioPartOutSourced;
    public Label switchAddLabel;
    public TextField addPartIHOSTxt;
    Random addPartUniqueID = new Random();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        addPartIDTxt.setText(((String.valueOf(addPartUniqueID.nextInt((100-10) + 100)))));
    }

    public boolean isInputValid() {
    Boolean valid = false;

    if (((Integer.parseInt(addPartMinTxt.getText()) < Integer.parseInt(addPartMaxTxt.getText()))) &&
            (Integer.parseInt(addPartMinTxt.getText()) < Integer.parseInt(addPartInvTxt.getText())) &&
            (Integer.parseInt(addPartInvTxt.getText()) < Integer.parseInt(addPartMaxTxt.getText())) &&
            (!addPartMinTxt.getText().trim().isEmpty()) &&
            (!addPartInvTxt.getText().trim().isEmpty()) &&
            (!addPartPriceTxt.getText().trim().isEmpty()) &&
            (!addPartNameTxt.getText().trim().isEmpty()) &&
            (!addPartMaxTxt.getText().trim().isEmpty()) &&
            (!addPartIHOSTxt.getText().trim().isEmpty())) {

        valid = true;
    }
    else {
        valid = false;

    }
    return valid;
}

    /**This button will save the part added, and go back to the main screen. It creates a new Part in Inventory.*/
    public void onSaveAddPart(ActionEvent actionEvent) throws Exception {
        try {
            if (isInputValid()) {

                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setContentText("Save changes?");
                Optional<ButtonType> result = alert.showAndWait();

                if (result.get() == ButtonType.OK) {

                    if ((radioPartInHouse.isSelected())) {
                        InHouse newIHPart = new InHouse(
                                Integer.parseInt(addPartIDTxt.getText()),
                                addPartNameTxt.getText(),
                                Double.parseDouble(addPartPriceTxt.getText()),
                                Integer.parseInt(addPartInvTxt.getText()),
                                Integer.parseInt(addPartMinTxt.getText()),
                                Integer.parseInt(addPartMaxTxt.getText()),
                                Integer.parseInt(addPartIHOSTxt.getText()));

                        Inventory.addPart(newIHPart);
                    } else {
                        OutSourced newOSPart = new OutSourced(
                                Integer.parseInt(addPartIDTxt.getText()),
                                addPartNameTxt.getText(),
                                Double.parseDouble(addPartPriceTxt.getText()),
                                Integer.parseInt(addPartInvTxt.getText()),
                                Integer.parseInt(addPartMinTxt.getText()),
                                Integer.parseInt(addPartMaxTxt.getText()),
                                (addPartIHOSTxt.getText()));

                        Inventory.addPart(newOSPart);
                    }
                    Parent root = FXMLLoader.load((getClass().getResource("/view/main.fxml")));
                    Stage window = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                    window.setScene(new Scene(root, 1000, 600));
                    window.show();
                } else {
                    alert.close();
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Confirmation Dialog");
                alert.setContentText("Error");
                alert.showAndWait();
            }
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Confirmation Dialog");
            alert.setContentText("Error. You must fill in all the boxes and Min < Inv < Max");
            alert.showAndWait();
        }
    }

    /**This button will cancel, and go back to the main screen. */
    public void onCancelAddPart(ActionEvent actionEvent) throws Exception {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setContentText("Cancel changes?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
        Parent root = FXMLLoader.load((getClass().getResource("/view/main.fxml")));
        Stage window = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
        window.setScene(new Scene(root,1000,600));
        window.show();

        } else {
            alert.close();
        }
    }

    /**This radio button is for InHouse in Add Part window. */
    public void onSetPartInHouse(ActionEvent actionEvent) {

        switchAddLabel.setText("Machine ID");
    }

    /**This radio button is for OutSourced in Add Part window. */
    public void onSetPartOutSourced(ActionEvent actionEvent) {

        switchAddLabel.setText("Company ID");
    }


    //END OF ADD PART CONTROLLER CLASS
}
