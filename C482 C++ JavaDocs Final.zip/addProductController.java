package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;
import java.util.Optional;
import java.util.Random;
import java.net.URL;
import java.util.ResourceBundle;

public class addProductController implements Initializable {

    public TextField searchBarAddProd;
    public Button searchButtonAddProd;

    public TableView<Part> addProdTopTable;
    public TableColumn<Part, Integer> partIDColTop;
    public TableColumn<Part, String> partNameColTop;
    public TableColumn<Part, Integer> partInvColTop;
    public TableColumn<Part, Double> partPriceColTop;

    public TableView<Part> addProdBottomTable;
    public TableColumn<Part, Integer> partIDColBottom;
    public TableColumn<Part, String> partNameColBottom;
    public TableColumn<Part, Integer> partInvColBottom;
    public TableColumn<Part, Double> partPriceColBottom;

    public Button saveAddProduct;
    public Button cancelAddProduct;
    public Button addProd;
    public Button removePart;

    public TextField addProdIDField;
    public TextField addProdNameField;
    public TextField addProdInvField;
    public TextField addProdPriceField;
    public TextField addProdMaxField;
    public TextField addProdMinField;

    Random addProdUniqueID = new Random();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        mainController.inventoryData();
        addProdIDField.setText(((String.valueOf(addProdUniqueID.nextInt((1000-10)+1000)))));
        addProdTopTable.setItems(Inventory.getAllParts());
        addProdBottomTable.setItems(Inventory.getAssociatedParts());

        partIDColTop.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColTop.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInvColTop.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceColTop.setCellValueFactory(new PropertyValueFactory<>("price"));

        partIDColBottom.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColBottom.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInvColBottom.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceColBottom.setCellValueFactory(new PropertyValueFactory<>("price"));

    }

    public boolean isInputValid() {
        Boolean valid = false;

        if (((Integer.parseInt(addProdMinField.getText()) < Integer.parseInt(addProdMaxField.getText()))) &&
                (Integer.parseInt(addProdMinField.getText()) < Integer.parseInt(addProdInvField.getText())) &&
                (Integer.parseInt(addProdInvField.getText()) < Integer.parseInt(addProdMaxField.getText())) &&
                (!addProdMinField.getText().trim().isEmpty()) &&
                (!addProdInvField.getText().trim().isEmpty()) &&
                (!addProdPriceField.getText().trim().isEmpty()) &&
                (!addProdNameField.getText().trim().isEmpty()) &&
                (!addProdMaxField.getText().trim().isEmpty()))
        {

            valid = true;
        }
        else {
            valid = false;

        }
        return valid;
    }

    /**This button will save the new product. */
    public void onSaveAddProduct(ActionEvent actionEvent) throws Exception {
        try {
            if (isInputValid()) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setContentText("Save changes?");
                Optional<ButtonType> result = alert.showAndWait();

                if (result.get() == ButtonType.OK) {

                    Product newProduct = new Product(
                            Integer.parseInt(addProdIDField.getText()),
                            addProdNameField.getText(),
                            Double.parseDouble(addProdPriceField.getText()),
                            Integer.parseInt(addProdInvField.getText()),
                            Integer.parseInt(addProdMinField.getText()),
                            Integer.parseInt(addProdMaxField.getText()));

                    Inventory.addProduct(newProduct);

                    Parent root = FXMLLoader.load((getClass().getResource("/view/main.fxml")));
                    Stage window = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                    window.setScene(new Scene(root, 1000, 600));
                    window.show();

                } else {
                    alert.close();
                }
            }
        }
        catch(Exception e){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error Dialog");
                alert.setHeaderText("Please complete all the boxes");
                alert.setContentText("Missing information");
                alert.showAndWait();
        }
    }

    /**This button will cancel creating a product, and return to the main window. */
    public void onCancelAddProduct(ActionEvent actionEvent) throws Exception {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setContentText("Cancel changes?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK){

            Parent root = FXMLLoader.load((getClass().getResource("/view/main.fxml")));
            Stage window = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            window.setScene(new Scene(root, 1000, 600));
            window.show();

        } else {
            alert.close();
        }
    }

    /**This button will move the part from the top table to the bottom table. */
    public void onAddProd(ActionEvent actionEvent) {

        Inventory.addAssociatedPart(addProdTopTable.getSelectionModel().getSelectedItem());
    }

    /**This button will move the part from the bottom table to the top table. */
    public void onRemovePart(ActionEvent actionEvent) {

        Inventory.deleteAssociatePart(addProdBottomTable.getSelectionModel().getSelectedItem());

        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning Dialog");
        alert.setContentText("That part has been removed");
        alert.showAndWait();
    }

    /**This button will execute the Part search in the top table. */
    public void onSearchAddProd(ActionEvent actionEvent) {

        String partEntryText = searchBarAddProd.getText();
        boolean errorTest = false;
        if (searchBarAddProd.getText().trim().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Please Enter a Part Name or ID");
            alert.showAndWait();
            errorTest = true;
        }
        try {
            if (!searchBarAddProd.getText().trim().isEmpty()) {
                for (Part partID : Inventory.getAllParts()) {
                    int partEntryID = Integer.parseInt(partEntryText);
                    if (partID.getId() == partEntryID) {
                        addProdTopTable.getSelectionModel().select(partID);
                        System.out.println("Found Part ID");
                        errorTest = true;
                    }
                }
            }
        } catch (NumberFormatException e) {
            if (!searchBarAddProd.getText().trim().isEmpty()) {
                for (Part partName : Inventory.getAllParts()) {
                    if (partName.getName().contains(partEntryText)) {
                        addProdTopTable.getSelectionModel().select(partName);
                        System.out.println("Found Part Name");
                        errorTest = true;
                    }
                }
            }
        }
        if (!errorTest) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Part Not Found");
            alert.showAndWait();
            System.out.println("Error. Part Not Found");
        }
    }

//END OF ADD PRODUCT CONTROLLER CLASS
}

