#include <iostream>

using namespace std;

enum class DegreeProgram { SECURITY = 0, NETWORK, SOFTWARE };




