#include <iostream>
#include <string>
#include "Roster.h"
using namespace std;

int main()
{
	cout << "C867 Scipting and Programming - Applications" << endl;
	cout << "Language: C++" << endl;
	cout << "Student ID: 004388148" << endl;
	cout << "Name: Jeffrey Linn" << endl;
	cout << endl;
	
	
	const string studentData[5] = { "A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
									"A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
									"A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
									"A4,Erin,Black,Erin.black@comcast.net,22,45,58,40,SECURITY",
									"A5,Jeff,Linn,jlinn19@wgu.edu,34,50,60,40,SOFTWARE"
	};
	
	Roster classRoster; 

	
	for (int i = 0; i < 5; ++i) {
		classRoster.parse(studentData[i]);
	}

	cout << endl;
	cout << "DISPLAYING ALL STUDENTS" << endl << endl;
	
	classRoster.printAll();
	
	cout << endl;
	cout << "DISPLAYING INVALID EMAILS " << endl << endl;
	
	classRoster.printInvalidEmails(); 

	cout << endl;
	cout << "DISPLAYING AVERAGE DAYS IN COURSE " << endl << endl;

	classRoster.printAverageDaysInCourse("A1");
	classRoster.printAverageDaysInCourse("A2");
	classRoster.printAverageDaysInCourse("A3");
	classRoster.printAverageDaysInCourse("A4");
	classRoster.printAverageDaysInCourse("A5");

	cout << endl << endl;
	cout << "DISPLAYING STUDENTS IN DEGREE PROGRAM : SOFTWARE" << endl;
	
	classRoster.printByDegreeProgram(DegreeProgram::SOFTWARE);

	cout << endl;
	cout << "REMOVING A3" << endl;
	
	classRoster.remove("A3"); 
	

	cout << endl;
	cout << "REMOVING A3 AGAIN " << endl << endl;
	
	classRoster.remove("A3");

	cout << endl;
	cout << "END OF PRINT" << endl;

	
	
	return 0;
}


