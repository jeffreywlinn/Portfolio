#include <iostream>
#include <string>
#include "Degree.h"

using namespace std;

class Student {
private:
	
public:	
	string StudentID;
	string FirstName;
	string LastName;
	string Email;
	int Age;
	int DaysInCourse[3] { 0,0,0 };
	int DaysInCourse1;
	int DaysInCourse2;
	int DaysInCourse3;
	DegreeProgram degreeprogram;
	string invalidEmail;

	Student();
	~Student();

	Student(string aStudentID, string aFirstName, string aLastName, string aEmail, int aAge, int aDaysInCourse1, int aDaysInCourse2, int aDaysInCourse3, DegreeProgram adegreeprogram);
	
	void print();

	void setStudentID(string aStudentID); 
	void setFirstName(string aFirstName);
	void setLastName(string aLastName);
	void setEmail(string aEmail);
	void setAge(int aAge);
	void setDaysInCourse(int aDaysInCourse1, int aDaysInCourse2, int aDaysInCourse3);
	void setDegreeProgram(DegreeProgram adegreeprogram);
	void setInvalidEmail(string aEmail);
	

	string getStudentID();
	string getFirstName();
	string getLastName();
	string getEmail();
	int getAge();
	int getDaysInCourse();
	string getInvalidEmail();
	DegreeProgram getDegreeProgram();
	
};
