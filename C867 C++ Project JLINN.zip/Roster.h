#include <iostream>
#include <string>
#include "Student.h"

using namespace std;


class Roster {

private:

public:
	
	~Roster();

	Student* classRosterArray[5];


	int index = 0; // to count in Add function
	
	void printAll();

	void add(string StudentID, string FirstName, string LastName, string Email, int Age, int DaysInCourse1, int DaysInCourse2, int DaysInCourse3, DegreeProgram degreeprogram);

	void remove(string StudentID);

	void printAverageDaysInCourse(string StudentID);

	void printInvalidEmails();

	void printByDegreeProgram(DegreeProgram degreeprogram);

	void parse(string data); 
};
