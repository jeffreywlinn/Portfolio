#include <iostream>
#include <string>
#include "Student.h"
using namespace std;


Student::Student() {
	StudentID = "A0";
	FirstName = "John";
	LastName = "Smith";
	Email = "1234ABC@Gmail.com";
	Age = 0;
	DaysInCourse[0] = DaysInCourse1;
	DaysInCourse[1] = DaysInCourse2;
	DaysInCourse[2] = DaysInCourse3;
	DaysInCourse1 = 0;
	DaysInCourse2 = 0;
	DaysInCourse3 = 0;
	degreeprogram = DegreeProgram::NETWORK;
	string invalidEmail = "1234Gmail.com";
}

Student::~Student() {
	
}

Student::Student(string aStudentID, string aFirstName, string aLastName, string aEmail, int aAge, int aDaysInCourse1, int aDaysInCourse2, int aDaysInCourse3, DegreeProgram adegreeprogram) {
		setStudentID(aStudentID);
		setFirstName(aFirstName);
		setLastName(aLastName);
		setEmail(aEmail);
		setAge(aAge);
		setDaysInCourse(aDaysInCourse1, aDaysInCourse2, aDaysInCourse3);
		setDegreeProgram(adegreeprogram);
		setInvalidEmail(aEmail);
	}

	void Student::print() {

		cout << StudentID << "\t" << FirstName << "\t" << LastName << "\t";
		cout << "\t" << Age << "\t";
		cout << "{" << DaysInCourse[0] << "," << DaysInCourse[1] << "," << DaysInCourse[2] << "}" << "\t";
		string degreeprogramstrings[] = { "SECURITY", "NETWORK", "SOFTWARE" };
		cout << degreeprogramstrings[(int)degreeprogram] << endl;

	};

	void Student::setStudentID(string aStudentID) {
		StudentID = aStudentID;
	};

	void Student::setFirstName(string aFirstName) {
		FirstName = aFirstName;
	};

	void Student::setLastName(string aLastName) {
		LastName = aLastName;
	};

	void Student::setEmail(string aEmail) {
		Email = aEmail;
	};

	void Student::setAge(int aAge) {
		Age = aAge;
	};

	void Student::setDaysInCourse(int aDaysInCourse1, int aDaysInCourse2, int aDaysInCourse3) {
		
		DaysInCourse[0] = aDaysInCourse1;
		DaysInCourse[1] = aDaysInCourse2;
		DaysInCourse[2] = aDaysInCourse3;
	};

	void Student::setDegreeProgram(DegreeProgram adegreeprogram) {
		degreeprogram = adegreeprogram;
	};

	void Student::setInvalidEmail(string aEmail) {
		invalidEmail = aEmail;
	}

	string Student::getEmail() {
		return Email;
	}
	
	string Student::getInvalidEmail() {
		return invalidEmail;
	}

	string Student::getStudentID() {
		return StudentID;
	}

	int Student::getDaysInCourse() {
		return (DaysInCourse[0] + DaysInCourse[1] + DaysInCourse[2]) / 3;
	}

	DegreeProgram Student::getDegreeProgram() {
		return degreeprogram;
	}