#include <iostream>
#include <string>
#include "Roster.h"
using namespace std;



void Roster::parse(string data) {
	size_t rhs = data.find(",");
	string StudentID = data.substr(0, rhs);

	size_t lhs = rhs + 1;
	rhs = data.find(",", lhs);
	string FirstName = data.substr(lhs, rhs - lhs);

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	string LastName = data.substr(lhs, rhs - lhs);

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	string Email = data.substr(lhs, rhs - lhs);

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	int Age = stoi(data.substr(lhs, rhs - lhs));

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	int DaysInCourse1 = stoi(data.substr(lhs, rhs - lhs));

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	int DaysInCourse2 = stoi(data.substr(lhs, rhs - lhs));

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	int DaysInCourse3 = stoi(data.substr(lhs, rhs - lhs));

	lhs = rhs + 1;
	rhs = data.find(",", lhs);
	string degreeprogram = (data.substr(lhs, rhs - lhs));

	DegreeProgram degree = DegreeProgram::NETWORK;
	if (degreeprogram == "NETWORK") {
		degree = DegreeProgram::NETWORK;
	}
	else if (degreeprogram == "SECURITY") {
		degree = DegreeProgram::SECURITY;
	}
	else if (degreeprogram == "SOFTWARE") {
		degree = DegreeProgram::SOFTWARE;
	}
	
	add(StudentID, FirstName, LastName, Email, Age, DaysInCourse1, DaysInCourse2, DaysInCourse3, degree);

	return;
}

void Roster::add(string StudentID, string FirstName, string LastName, string Email, int Age, int DaysInCourse1, int DaysInCourse2, int DaysInCourse3, DegreeProgram degreeprogram) {
	
	{classRosterArray[index] = new Student(StudentID, FirstName, LastName, Email, Age, DaysInCourse1, DaysInCourse2, DaysInCourse3, degreeprogram);
	index++;
	}

};

void Roster::printAll() { 
	
	for (index = 0; index < 5; index++) {
		classRosterArray[index]->print();
	}
	
};

void Roster::printInvalidEmails() {

	for (index = 0; index < 5; index++ ) {
		
		string invalidEmail = classRosterArray[index]->getInvalidEmail();
		int At = 0;
		int Dot = 0;
		int Space = 0;

		for (unsigned int i = 0; i < invalidEmail.size(); i++) {

			if (invalidEmail[i] == ' ') {
				Space = 1;
			}
			if (invalidEmail[i] == '@') {
				At = i;
			}
			if (invalidEmail[i] == '.') {
				Dot = i;
			}
		}
		if (At == 0) {
			cout << invalidEmail << " - is invalid" << endl;
		}
		if (Dot == 0) {
			cout << invalidEmail << " - is invalid" << endl;
		}
		if (Space == 1) {
			cout << invalidEmail << " - is invalid" << endl;
		}
	}
}

void Roster::printAverageDaysInCourse(string StudentID) { 

	if (StudentID == "A1") {
		cout << "Student " << StudentID << " average days in courses: " << classRosterArray[0]->getDaysInCourse() << endl;
	}
	else if (StudentID == "A2") {
		cout << "Student " << StudentID << " average days in courses: " << classRosterArray[1]->getDaysInCourse() << endl;
	}
	else if (StudentID == "A3") {
		cout << "Student " << StudentID << " average days in courses: " << classRosterArray[2]->getDaysInCourse() <<endl;
	}
	else if (StudentID == "A4") {
		cout << "Student " << StudentID << " average days in courses: " << classRosterArray[3]->getDaysInCourse() << endl;
	}
	else if (StudentID == "A5") {
		cout << "Student " << StudentID << " average days in courses: " << classRosterArray[4]->getDaysInCourse() << endl;
	}
	
	else { cout << "Student Not Found"; };
}

void Roster::printByDegreeProgram(DegreeProgram degreeprogram) {
	
	for (int i = 0; i < 5; i++) {
		
		if (degreeprogram == classRosterArray[i]->getDegreeProgram()) {
			classRosterArray[i]->print();
		}
		else { }
	}
}

void Roster::remove(string StudentID) {
	int SIZE = 5;
	bool status = false;

for (int i = 0; i < SIZE; i++) {
	if (classRosterArray[i]->getStudentID() == StudentID)
		for (int i = 0; i < SIZE; i++) {
			if (classRosterArray[i]->getStudentID() == StudentID) {
					status = true;
					delete classRosterArray[i];
					--SIZE;
					classRosterArray[i] = classRosterArray[SIZE];
					classRosterArray[i]->print();
			}
			else {
					classRosterArray[i]->print();
			}
		}
	}
if (status == false) { cout << "Student " << StudentID << " was not found." << endl << endl; }
}


Roster::~Roster() {
	for (int i = 0; i < 4; i++) {
		delete classRosterArray[i];
	}
} 

/*
void Roster::remove(string StudentID) {

	bool status = false;

	for (int i = 0; i < 5; i++) {
		if (classRosterArray[i]->getStudentID() == StudentID) {

			for (int i = 0; i < 5; i++) {
				if (classRosterArray[i]->getStudentID() == StudentID) {
					//classRosterArray[i] = classRosterArray[i + 1];
					delete classRosterArray[i + 1];
					status = true;
				}
				else {
					classRosterArray[i]->print();
				}
			}
		}
	}
	if (status == false) { cout << "Student " << StudentID << " was not found." << endl << endl; }
}



*/