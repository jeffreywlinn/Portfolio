package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Inventory {

    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    private static ObservableList<Part> associatedParts = FXCollections.observableArrayList();

    public static ObservableList<Part> getAllParts() {

        return allParts;
    }
    public static ObservableList<Product> getAllProducts() {

        return allProducts;
    }
    public static ObservableList<Part> getAssociatedParts() {
        return associatedParts;
    }

    public static void addPart(Part newPart) {

        allParts.add(newPart);
    }
    public static void addProduct(Product newProduct) {

        allProducts.add(newProduct);
    }
    public static void addAssociatedPart(Part associatePart) {

        associatedParts.add(associatePart);
    }

    public static Part lookupPart(int partID) {

        for(Part lookup : allParts) {
            if(lookup.getId() == partID) {
                return lookup;
            }
        }
        return null;
    }

    public static Product lookupProduct(int productID) {

        for(Product prodLookup : allProducts) {
            if(prodLookup.getID() == productID) {
                return prodLookup;
            }
        }
        return null;
    }

    public static Part lookupPart(String partName) {

        for(Part nameLookup : allParts) {
        if(nameLookup.getName() == partName) {
            return nameLookup;
        }
    }
        return null;
    }

    public static Product lookupProduct(String productName) {

        for(Product nameLookup : allProducts) {
            if(nameLookup.getName() == productName) {
                return nameLookup;
            }
        }
        return null;
    }

    public static void updatePart(int index, Part selectedPart) {

        Part assignData = Inventory.lookupPart(index);
        Inventory.deletePart(assignData);
        Inventory.addPart(selectedPart);
    }

    public static void updateProduct(int index, Product selectedProduct) {

        Product assignData = Inventory.lookupProduct(index);
        Inventory.deleteProduct(assignData);
        Inventory.addProduct(selectedProduct);
    }

    public static void deletePart(Part selectedPart) {

        allParts.remove(selectedPart);
    }

    public static void deleteProduct(Product selectedProduct) {

        allProducts.remove(selectedProduct);
    }

    public static void deleteAssociatePart(Part selectedAssociatePart) {

        associatedParts.remove(selectedAssociatePart);
    }


    //END OF INVENTORY CLASS
}
