package controller;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;

public class modifyProductController implements Initializable {

    public Button cancelModifyProduct;
    public Button saveModifyProduct;
    public Button addModProd;
    public Button removeModProd;

    public TableView<Part> topTableModProd;
    public TableView<Part> bottomTableModProd;

    public TextField searchBarModProd;
    public Button searchButtonModProd;

    public TableColumn<Part, Integer> topPartID;
    public TableColumn<Part, String> topPartName;
    public TableColumn<Part, Integer> topPartInv;
    public TableColumn<Part, Integer> topPartPrice;

    public TableColumn<Part, Integer> bottomPartID;
    public TableColumn<Part, String> bottomPartName;
    public TableColumn<Part, Integer> bottomPartInv;
    public TableColumn<Part, Integer> bottomPartPrice;

    public TextField modProdCarryID;
    public TextField modProdName;
    public TextField ModProdInv;
    public TextField modProdPrice;
    public TextField modProdMax;
    public TextField modProdMin;

    public void sendProduct(Product product) {

        modProdCarryID.setText(String.valueOf(product.getID()));
        modProdName.setText(product.getName());
        ModProdInv.setText(String.valueOf(product.getStock()));
        modProdPrice.setText(String.valueOf(product.getPrice()));
        modProdMax.setText(String.valueOf(product.getMax()));
        modProdMin.setText(String.valueOf(product.getMin()));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        mainController.inventoryData();

        topTableModProd.setItems(Inventory.getAllParts());
        topPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        topPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        topPartInv.setCellValueFactory(new PropertyValueFactory<>("stock"));
        topPartPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

        bottomTableModProd.setItems(Inventory.getAssociatedParts());
        bottomPartID.setCellValueFactory(new PropertyValueFactory<>("id"));
        bottomPartName.setCellValueFactory(new PropertyValueFactory<>("name"));
        bottomPartInv.setCellValueFactory(new PropertyValueFactory<>("stock"));
        bottomPartPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    /**This method is used to check all boxes are filled in prior to Saving. */
    public boolean isInputValid() {
        Boolean valid = false;

        if (((Integer.parseInt(modProdMin.getText()) < Integer.parseInt(modProdMax.getText()))) &&
                (Integer.parseInt(modProdMin.getText()) < Integer.parseInt(ModProdInv.getText())) &&
                (Integer.parseInt(ModProdInv.getText()) < Integer.parseInt(modProdMax.getText())) &&
                (!modProdMin.getText().trim().isEmpty()) &&
                (!ModProdInv.getText().trim().isEmpty()) &&
                (!modProdPrice.getText().trim().isEmpty()) &&
                (!modProdName.getText().trim().isEmpty()) &&
                (!modProdMax.getText().trim().isEmpty()))
                 {

            valid = true;
        }
        else {
            valid = false;

        }
        return valid;
    }

    /**This button will save the Product modified, and return to main window. */
    public void onSaveModifyProduct(ActionEvent actionEvent) throws Exception {
        try {
            if (isInputValid()) {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setContentText("Save changes?");
                Optional<ButtonType> result = alert.showAndWait();

                if (result.get() == ButtonType.OK) {
                    Product newProduct = new Product(
                            Integer.parseInt(modProdCarryID.getText()),
                            modProdName.getText(),
                            Double.parseDouble(modProdPrice.getText()),
                            Integer.parseInt(ModProdInv.getText()),
                            Integer.parseInt(modProdMin.getText()),
                            Integer.parseInt(modProdMax.getText()));

                    Inventory.updateProduct(Integer.parseInt(modProdCarryID.getText()), newProduct);

                    Parent root = FXMLLoader.load((getClass().getResource("/view/main.fxml")));
                    Stage window = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                    window.setScene(new Scene(root, 1000, 600));
                    window.show();

                } else {
                    alert.close();
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error Dialog");
                alert.setHeaderText("Please complete all the boxes");
                alert.setContentText("And ensure Min < Inv < Max");
                alert.showAndWait();
            }
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Please complete all the boxes");
            alert.setContentText("And ensure Min < Inv < Max");
            alert.showAndWait();
        }
    }

    /**This button will cancel, and return to main window. */
    public void onCancelModifyProduct(ActionEvent actionEvent) throws Exception {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setContentText("You might lose unsaved work. Are you sure?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK){

            Parent root = FXMLLoader.load((getClass().getResource("/view/main.fxml")));
            Stage window = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
            window.setScene(new Scene(root,1000,600));
            window.show();

        } else {
            alert.close();
        }
    }

    /**This button will add part to the product. */
    public void onAddModProd(ActionEvent actionEvent) {

       Inventory.addAssociatedPart(topTableModProd.getSelectionModel().getSelectedItem());
    }

    /**This button will move the part from the bottom table to the top table. */
    public void onRemoveModProd(ActionEvent actionEvent) {

        Inventory.deleteAssociatePart(bottomTableModProd.getSelectionModel().getSelectedItem());

        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning Dialog");
        alert.setContentText("That part has been removed.");
        alert.showAndWait();
    }

    /**This button will execute the Part search in the top table. */
    public void onSearchModProd(ActionEvent actionEvent) {

        String partEntryText = searchBarModProd.getText();
        boolean errorTest = false;
        if (searchBarModProd.getText().trim().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Please Enter a Part Name or ID");
            alert.showAndWait();
            errorTest = true;
        }
        try {
            if (!searchBarModProd.getText().trim().isEmpty()) {
                for (Part partID : Inventory.getAllParts()) {
                    int partEntryID = Integer.parseInt(partEntryText);
                    if (partID.getId() == partEntryID) {
                        topTableModProd.getSelectionModel().select(partID);
                        System.out.println("Found Part ID");
                        errorTest = true;
                    }
                }
            }
        } catch (NumberFormatException e) {
            if (!searchBarModProd.getText().trim().isEmpty()) {
                for (Part partName : Inventory.getAllParts()) {
                    if (partName.getName().contains(partEntryText)) {
                        topTableModProd.getSelectionModel().select(partName);
                        System.out.println("Found Part Name");
                        errorTest = true;
                    }
                }
            }
        }
        if (!errorTest) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Part Not Found");
            alert.showAndWait();
            System.out.println("Error. Part Not Found");
        }

    }


    // END OF CLASS MODIFY PRODUCT CONTROLLER
}

