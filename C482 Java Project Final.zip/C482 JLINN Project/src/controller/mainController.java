package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.*;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**JavaDoc files location C:\Users\linnj\IdeaProjects\C482 JLINN Project\src\controller\JLINN C482 JavaDoc Files.zip*/

public class mainController<partsList, productsList> implements Initializable {
    Stage stage;
    Parent scene;

    public TableView<Part> partsTable;
    public TableColumn<Part, Integer> partIDCol;
    public TableColumn<Part, String> partNameCol;
    public TableColumn<Part, Integer> partInventoryCol;
    public TableColumn<Part, Double> partPriceCol;
    public TableColumn<Part, Integer> partMinCol;
    public TableColumn<Part, Integer> partMaxCol;

    public TableView<Product> productsTable;
    public TableColumn<Product, Integer> productIDCol;
    public TableColumn<Product, String> productNameCol;
    public TableColumn<Product, Integer> productInventoryCol;
    public TableColumn<Product, Double> productPriceCol;
    public TableColumn<Product, Integer> productMinCol;
    public TableColumn<Product, Integer> productMaxCol;

    public Button addPart;
    public Button addProduct;
    public Button modifyPart;
    public Button deletePart;
    public Button modifyProduct;
    public Button deleteProduct;

    public TextField partsSearch;
    public TextField prodSearch;
    public Label TheLabel;
    public Button partsSearchButton;
    public Button prodSearchButton;
    public Button exitButton;

    private static boolean firstTime = true;

    /**
     * This method will populate the Parts and Products tables.
     * It has a logic test labeled "firstTime" to help prohibit duplication of entries.
     */
    public static void inventoryData() {
        if (!firstTime) {
            return;
        }
        firstTime = false;

        Inventory.addProduct(new Product(1, "Computer", 100, 5, 1, 20));
        Inventory.addProduct(new Product(2, "Printer", 75, 250, 5, 30));
        Inventory.addProduct(new Product(3, "Television", 500, 42, 7, 90));

        Inventory.addPart(new InHouse(1, "Processor", 50, 1000, 100, 5000, 4579));
        Inventory.addPart(new InHouse(2, "RAM", 25, 700, 50, 1000, 3332));
        Inventory.addPart(new OutSourced(3, "Ink", 15, 2500, 150, 500, "Xerox"));
        Inventory.addPart(new InHouse(4, "LCD Screen", 110, 43, 30, 70, 5009));
        Inventory.addPart(new OutSourced(5, "Paper", 5, 5000, 2000, 10000, "Xerox"));
        Inventory.addPart(new OutSourced(6, "Power Cord", 3, 900, 250, 1000, "Staples"));

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        inventoryData();

        partsTable.setItems(Inventory.getAllParts());
        productsTable.setItems(Inventory.getAllProducts());

        partIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventoryCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        partMinCol.setCellValueFactory(new PropertyValueFactory<>("min"));
        partMaxCol.setCellValueFactory(new PropertyValueFactory<>("max"));

        productIDCol.setCellValueFactory(new PropertyValueFactory<>("ID"));
        productNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInventoryCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        productMinCol.setCellValueFactory(new PropertyValueFactory<>("min"));
        productMaxCol.setCellValueFactory(new PropertyValueFactory<>("max"));

    }

    /**
     * This button take user to Add Part window.
     */
    public void onAddPart(ActionEvent actionEvent) throws Exception {
        Parent root = FXMLLoader.load((getClass().getResource("/view/addPart.fxml")));
        Stage window = (Stage) addPart.getScene().getWindow();
        window.setScene(new Scene(root, 1000, 600));
        System.out.println("To Adding Part");
    }

    /**
     * This button take user to Add Product window.
     */
    public void onAddProduct(ActionEvent actionEvent) throws Exception {

        Parent root = FXMLLoader.load((getClass().getResource("/view/addProduct.fxml")));
        Stage window = (Stage) addProduct.getScene().getWindow();
        window.setScene(new Scene(root, 1000, 600));
        System.out.println("To Adding Product");
    }

    /**
     * This button takes user to Modify Part window. It sends the data of the selected Part to the next window for modifying.
     * If no Part is selected, an exception will be caught and an Alert will fire.
     */
    public void onModifyPart(ActionEvent actionEvent) throws Exception {

        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/modifyPart.fxml"));
            loader.load();
            modifyPartController ModPartController = loader.getController();
            ModPartController.sendPart(partsTable.getSelectionModel().getSelectedItem());

            stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene));
            stage.show();
            System.out.println("Modify Part Clicked");

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Part Selection");
            alert.setContentText("No Part Selected");
            alert.showAndWait();
            System.out.println("Please Select A Part.");
        }
    }

    /**
     * This button take user to Modify Product window.
     */
    public void onModifyProduct(ActionEvent actionEvent) throws Exception {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/modifyProduct.fxml"));
            loader.load();
            modifyProductController ModProductController = loader.getController();
            ModProductController.sendProduct(productsTable.getSelectionModel().getSelectedItem());

            stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            Parent scene = loader.getRoot();
            stage.setScene(new Scene(scene));
            stage.show();
            System.out.println("Modify Product Clicked");

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Product Selection");
            alert.setContentText("No Product Selected");
            alert.showAndWait();
            System.out.println("Please Select A Product.");
        }
    }

    /**
     * This button will delete the selected Part.
     */
    public void onDeletePart(ActionEvent actionEvent) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("You're about to Delete a Part");
        alert.setContentText("Are you sure?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            Inventory.getAllParts().remove(partsTable.getSelectionModel().getSelectedItem());
            System.out.println("Part Deleted");
            Alert OKAlert = new Alert(Alert.AlertType.WARNING);
            OKAlert.setTitle("Warning Dialog");
            OKAlert.setContentText("The part has been deleted.");
            OKAlert.showAndWait();

        } else {
            alert.close();
        }
    }

    /** This method is used to confirm the selected Product does not have Parts associated prior to deleting the Product. */
    public boolean isDeleteValid() {

        Boolean valid = false;

        if (Inventory.getAssociatedParts().isEmpty() == true) {
            valid = true;
        }
        else { System.out.println("Valid is false");
        }
        return valid;
    }

    /**
     * This button will delete the selected Product.
     */
    public void onDeleteProduct(ActionEvent actionEvent) throws Exception {

        if (isDeleteValid()) {

                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Dialog");
                alert.setHeaderText("You're about to Delete a Product");
                alert.setContentText("Are you sure?");
                Optional<ButtonType> result = alert.showAndWait();

                if (result.get() == ButtonType.OK) {
                    Inventory.getAllProducts().remove(productsTable.getSelectionModel().getSelectedItem());
                } else {
                    alert.close();
                }

        } else {
                Alert alert2 = new Alert(Alert.AlertType.WARNING);
                alert2.setTitle("Parts Associated with Product");
                alert2.setHeaderText("You can't delete a Product with associated Parts");
                alert2.setContentText("Modify the Product to remove the Parts prior to Deleting");
                alert2.show();
        }
    }

    /**
     * This button will execute the Parts search.
     * There was a runtime error with the conversion of a string with improper format to a numeric value.
     * A Number Format Exception was entered to the Try Catch blocks to fix that error.
     */
    public void onPartsSearchButton(ActionEvent actionEvent) {

        String partEntryText = partsSearch.getText();
        boolean errorTest = false;
        if (partsSearch.getText().trim().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Please Enter a Part Name or ID");
            alert.showAndWait();
            errorTest = true;
        }
        try {
            if (!partsSearch.getText().trim().isEmpty()) {
                for (Part partID : Inventory.getAllParts()) {
                    int partEntryID = Integer.parseInt(partEntryText);
                    if (partID.getId() == partEntryID) {
                        partsTable.getSelectionModel().select(partID);
                        System.out.println("Found Part ID");
                        errorTest = true;
                    }
                }
            }
        } catch (NumberFormatException e) {
            if (!partsSearch.getText().trim().isEmpty()) {
                for (Part partName : Inventory.getAllParts()) {
                    if (partName.getName().contains(partEntryText)) {
                        partsTable.getSelectionModel().select(partName);
                        System.out.println("Found Part Name");
                        errorTest = true;
                    }
                }
            }
        }
        if (!errorTest) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Part Not Found");
            alert.showAndWait();
            System.out.println("Error. Part Not Found");
        }
    }

    /** This will execute the Product search. */
    public void onProdSearchButton(ActionEvent actionEvent) {

        String prodEntryText = prodSearch.getText();
        boolean errorTest = false;
        if (prodSearch.getText().trim().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Please Enter a Product Name or ID");
            alert.showAndWait();
            errorTest = true;
        }
        try {
            if (!prodSearch.getText().trim().isEmpty()) {
                for (Product prodID : Inventory.getAllProducts()) {
                    int prodEntryID = Integer.parseInt(prodEntryText);
                    if (prodID.getID() == prodEntryID) {
                        productsTable.getSelectionModel().select(prodID);
                        System.out.println("Found Product ID");
                        errorTest = true;
                    }
                }
            }
        } catch (NumberFormatException e) {
            if (!prodSearch.getText().trim().isEmpty()) {
                for (Product productName : Inventory.getAllProducts()) {
                    if (productName.getName().contains(prodEntryText)) {
                        productsTable.getSelectionModel().select(productName);
                        System.out.println("Found Product Name");
                        errorTest = true;
                    }
                }
            }
        }
        if (!errorTest) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setContentText("Product Not Found");
            alert.showAndWait();
            System.out.println("Error. Product Not Found");
        }
    }

    /**This button will close the program. */
    public void onExitButton(ActionEvent actionEvent) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Exit Program");
        alert.setContentText("Are you sure you want to exit?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){
            System.exit(0);
        } else {
            alert.close();
        }
    }


    // END OF CLASS MAIN CONTROLLER
}
