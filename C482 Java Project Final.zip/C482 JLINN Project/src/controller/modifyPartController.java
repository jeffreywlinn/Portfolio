package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.InHouse;
import model.Inventory;
import model.OutSourced;
import model.Part;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

public class modifyPartController implements Initializable {

    public ToggleGroup modGroup;
    public Button saveModifyPart;
    public Button cancelModifyPart;
    public RadioButton radioModPartIH;
    public RadioButton radioModPartOS;
    public Label switchModPartLabel;
    public TextField modPartCarryID;
    public TextField modPartName;
    public TextField modPartInv;
    public TextField modPartPrice;
    public TextField modPartMax;
    public TextField modPartIHOS;
    public TextField modPartMin;

    public void sendPart(Part part) {

        modPartCarryID.setText(String.valueOf(part.getId()));
        modPartName.setText((part.getName()));
        modPartInv.setText(String.valueOf(part.getStock()));
        modPartPrice.setText(String.valueOf(part.getPrice()));
        modPartMax.setText(String.valueOf(part.getMax()));
        modPartMin.setText(String.valueOf(part.getMin()));

        if(part instanceof InHouse) {
            modPartIHOS.setText(String.valueOf(((InHouse)part).getMachineID()));
            radioModPartIH.setSelected(true);
            switchModPartLabel.setText("Machine ID");

        } else {
            modPartIHOS.setText(String.valueOf(((OutSourced)part).getCompanyName()));
            radioModPartOS.setSelected(true);
            switchModPartLabel.setText("Company ID");
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    /**This button will save the Part modified. If all boxes are completed,
     * it will save and return to the main window
     * Else, it will show an error dialog. */
    public void onSaveModifyPart(ActionEvent actionEvent) throws Exception{

        try {
            if (radioModPartIH.isSelected()) {
                InHouse newIHPart = new InHouse(
                        Integer.parseInt(modPartCarryID.getText()),
                        modPartName.getText(),
                        Double.parseDouble(modPartPrice.getText()),
                        Integer.parseInt(modPartInv.getText()),
                        Integer.parseInt(modPartMin.getText()),
                        Integer.parseInt(modPartMax.getText()),
                        Integer.parseInt(modPartIHOS.getText()));

                Inventory.updatePart(Integer.parseInt(modPartCarryID.getText()), newIHPart);

            } else {
                OutSourced newOSPart = new OutSourced(
                        Integer.parseInt(modPartCarryID.getText()),
                        modPartName.getText(),
                        Double.parseDouble(modPartPrice.getText()),
                        Integer.parseInt(modPartInv.getText()),
                        Integer.parseInt(modPartMin.getText()),
                        Integer.parseInt(modPartMax.getText()),
                        (modPartIHOS.getText()));

                Inventory.updatePart(Integer.parseInt(modPartCarryID.getText()), newOSPart);
            }

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Dialog");
            alert.setContentText("Save changes?");
            Optional<ButtonType> result = alert.showAndWait();

            if (result.get() == ButtonType.OK){

                Parent root = FXMLLoader.load((getClass().getResource("/view/main.fxml")));
                Stage window = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                window.setScene(new Scene(root, 1000, 600));
                window.show();

            } else {
                alert.close();
            }
        }
        catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error Dialog");
            alert.setHeaderText("Please complete all the boxes");
            alert.setContentText("Missing information");
            alert.showAndWait();
        }
    }

    /**This button will cancel, and return to main window. */
    public void onCancelModifyPart(ActionEvent actionEvent) throws Exception {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Cancel changes?");
        alert.setContentText("Are you sure?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK){

            Parent root = FXMLLoader.load((getClass().getResource("/view/main.fxml")));
            Stage window = (Stage) ((Node)actionEvent.getSource()).getScene().getWindow();
            window.setScene(new Scene(root,1000,600));
            window.show();

        } else {
            alert.close();
        }
    }

    /**This radio button will set part to InHouse. It will also clear the contents of the text field. */
    public void onSetModPartIH(ActionEvent actionEvent) {

        switchModPartLabel.setText("Machine ID");
        modPartIHOS.clear();
    }

    /**This radio button will set part to OutSourced. It will also clear the contents of the text field. */
    public void onSetModPartOS(ActionEvent actionEvent) {

        switchModPartLabel.setText("Company ID");
        modPartIHOS.clear();
    }

    //END OF MODIFY PART CONTROLLER CLASS
}

