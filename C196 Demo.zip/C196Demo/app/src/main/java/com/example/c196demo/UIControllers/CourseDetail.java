package com.example.c196demo.UIControllers;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.c196demo.Adapters.CourseDetailAdapter;
import com.example.c196demo.Adapters.TermDetailAdapter;
import com.example.c196demo.Database.Repository;
import com.example.c196demo.Entities.Assessments;
import com.example.c196demo.Entities.Courses;
import com.example.c196demo.Entities.Terms;
import com.example.c196demo.R;
import com.google.android.material.snackbar.Snackbar;

import java.nio.channels.AcceptPendingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CourseDetail extends AppCompatActivity {

    private Repository repository;

    TextView editCourseID;
    String courseID;
    EditText editCourseTermID;
    String courseTermID;
    TextView editCourseTitle;
    String courseTitle;
    TextView editCourseStatus;
    String courseStatus;
    TextView editCourseStart;
    String courseStartDate;
    TextView editCourseEnd;
    String courseEndDate;
    TextView editInstructorName;
    String instructorName;
    TextView editInstructorPhone;
    String instructorPhone;
    TextView editInstructorEmail;
    String instructorEmail;
    TextView editNote;
    String note;

    Calendar courseCalendar = Calendar.getInstance();

    DatePickerDialog.OnDateSetListener calCourseStart;
    DatePickerDialog.OnDateSetListener calCourseEnd;
    Long dateStart; // date for alarm
    Long dateEnd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        repository = new Repository(getApplication());

        editCourseStart = findViewById(R.id.editTextCourseStartDate);
        courseStartDate = getIntent().getStringExtra("termDetailCourseStart");
        editCourseStart.setText(courseStartDate);

        editCourseEnd = findViewById(R.id.editTextCourseEndDate);
        courseEndDate = getIntent().getStringExtra("termDetailCourseEnd");
        editCourseEnd.setText(courseEndDate);

        editCourseID = findViewById(R.id.editTextCourseID);
        courseID = getIntent().getStringExtra("termDetailCourseID");
        editCourseID.setText(courseID);

        editCourseTermID = findViewById(R.id.editTextTermID);
        courseTermID = getIntent().getStringExtra("termDetailTermID");
        editCourseTermID.setText(courseTermID);

        editCourseTitle = findViewById(R.id.courseDetailTitle);
        courseTitle = getIntent().getStringExtra("termDetailCourseTitle");
        editCourseTitle.setText(courseTitle);

        editCourseStatus = findViewById(R.id.editTextCourseStatus);
        courseStatus = getIntent().getStringExtra("termDetailCourseStatus");
        editCourseStatus.setText(courseStatus);

        RadioButton inProgress = findViewById(R.id.InProgress);
        RadioButton completed = findViewById(R.id.completed);
        RadioButton notStarted = findViewById(R.id.planToTake);
        RadioButton dropped = findViewById(R.id.dropped);

        RadioGroup radioGroup;
        radioGroup = findViewById(R.id.courseStatusGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton radioButton = findViewById(i);
                if(radioButton.isChecked()) {
                    editCourseStatus.setText(radioButton.getText());
            }
        }});

        if(courseStatus!= null && courseStatus.equalsIgnoreCase("In Progress") ) { inProgress.setChecked(true); }
        if(courseStatus!= null && courseStatus.equalsIgnoreCase("Completed")){ completed.setChecked(true); }
        if(courseStatus!= null && courseStatus.equalsIgnoreCase("Plan To Take")){ notStarted.setChecked(true); }
        if(courseStatus!= null && courseStatus.equalsIgnoreCase("Dropped")){ dropped.setChecked(true); }

        editInstructorName = findViewById(R.id.editTextCourseInstName);
        instructorName = getIntent().getStringExtra("termDetailCourseInstructor");
        editInstructorName.setText(instructorName);

        editInstructorEmail = findViewById(R.id.editTextInstEmail);
        instructorEmail = getIntent().getStringExtra("termDetailInstructorEmail");
        editInstructorEmail.setText(instructorEmail);

        editInstructorPhone = findViewById(R.id.editTextCourseInstPhone);
        instructorPhone = getIntent().getStringExtra("termDetailInstructorPhone");
        editInstructorPhone.setText(instructorPhone);

        editNote = findViewById(R.id.editTextCourseNote);
        note = getIntent().getStringExtra("termDetailNote");
        editNote.setText(note);

        /**This is the list of Assessments for the selected Course*/
        if(!editCourseID.getText().toString().isEmpty()) {
            List<Assessments> allAssessments = repository.getAssociatedAssessments(Integer.parseInt(courseID));
            RecyclerView recyclerView = findViewById(R.id.courseAssessmentRecycler);
            final CourseDetailAdapter courseDetailAdapter = new CourseDetailAdapter(this);
            courseDetailAdapter.setAssessments(allAssessments);
            recyclerView.setAdapter(courseDetailAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        } else {
            List<Assessments> allAssessments = repository.getAllAssessments();
            RecyclerView recyclerView = findViewById(R.id.courseAssessmentRecycler);
            final CourseDetailAdapter courseDetailAdapter = new CourseDetailAdapter(this);
            courseDetailAdapter.setAssessments(allAssessments);
            recyclerView.setAdapter(courseDetailAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        }

        calCourseStart = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                courseCalendar.set(Calendar.YEAR, year);
                courseCalendar.set(Calendar.MONTH, monthOfYear);
                courseCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelStart();
            }
        };
        editCourseStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(CourseDetail.this, calCourseStart, courseCalendar
                        .get(Calendar.YEAR), courseCalendar.get(Calendar.MONTH), courseCalendar.get(Calendar.DAY_OF_MONTH))
                        .show();
            }
        });

        calCourseEnd = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                courseCalendar.set(Calendar.YEAR, year);
                courseCalendar.set(Calendar.MONTH, monthOfYear);
                courseCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelEnd();
            }
        };
        editCourseEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(CourseDetail.this, calCourseEnd, courseCalendar
                        .get(Calendar.YEAR), courseCalendar.get(Calendar.MONTH), courseCalendar.get(Calendar.DAY_OF_MONTH))
                        .show();
            }
        });

    }



    private void updateLabelStart() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editCourseStart.setText(sdf.format(courseCalendar.getTime()));
    }
    private void updateLabelEnd() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editCourseEnd.setText(sdf.format(courseCalendar.getTime()));
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_course_detail, menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home:
                this.finish();
                return true;

            case R.id.course_detail_refresh:
                repository = new Repository(getApplication());
                List<Assessments> associatedAssessments = repository.getAssociatedAssessments(Integer.parseInt(courseID));
                RecyclerView recyclerView = findViewById(R.id.courseAssessmentRecycler);
                final CourseDetailAdapter courseDetailAdapter = new CourseDetailAdapter(this);
                courseDetailAdapter.setAssessments(associatedAssessments);
                recyclerView.setAdapter(courseDetailAdapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                return true;

            case R.id.course_saving:
                    String start = editCourseStart.getText().toString();
                    String end = editCourseEnd.getText().toString();
                    String courseID = editCourseID.getText().toString();
                    String courseTitle = editCourseTitle.getText().toString();
                    String courseTermID = editCourseTermID.getText().toString();
                    String courseStatus = editCourseStatus.getText().toString();
                    String instructorName = editInstructorName.getText().toString();
                    String instructorPhone = editInstructorPhone.getText().toString();
                    String instructorEmail = editInstructorEmail.getText().toString();
                    String note = editNote.getText().toString();


                    if(editNote.getText().toString().isEmpty()) {
                    editNote.setText("Empty");
                    }

                    if(start.isEmpty() || end.isEmpty() || courseTitle.isEmpty() || courseTermID.isEmpty() || courseStatus.isEmpty() ||
                            instructorName.isEmpty() || instructorEmail.isEmpty() || instructorPhone.isEmpty()) {

                        View view = findViewById(R.id.editTextCourseNote);
                        Snackbar.make(view, "Must Complete Fields", Snackbar.LENGTH_SHORT).setAnchorView(editNote).show();

                    } else {
                        int termIDVal = Integer.parseInt(courseTermID);
                        if(courseID.isEmpty() ) {
                            int courseIDVal = 0;
                            //editCourseID.setText("0");
                            Courses newCourse = new Courses(termIDVal, courseIDVal, courseTitle, start, end, courseStatus, instructorName, instructorPhone, instructorEmail, note);
                            repository.insert(newCourse);
                            Intent intentD = new Intent(CourseDetail.this, CourseList.class);
                            startActivity(intentD);

                        }
                        if(!courseID.isEmpty()){
                            int courseIDVal = Integer.parseInt(courseID);
                            Courses updateCourse = new Courses(termIDVal, courseIDVal, courseTitle, start, end, courseStatus, instructorName, instructorPhone, instructorEmail, note);
                            repository.update(updateCourse);
                            Intent intentD = new Intent(CourseDetail.this, CourseList.class);
                            startActivity(intentD);
                        }

                    }



                return true;

            case R.id.assessment_add:
                Intent intentC = new Intent(CourseDetail.this, AssessmentDetail.class);
                startActivity(intentC);
                return true;

            case R.id.course_sharing:
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, editNote.getText().toString());
                sendIntent.putExtra(Intent.EXTRA_TITLE, editCourseTitle.getText().toString());
                sendIntent.setType("text/plain");
                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
                return true;

            case R.id.course_delete:
                int courseToDelete = Integer.parseInt(editCourseID.getText().toString());
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Delete Course").setMessage("Are you sure?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                for (Courses C : repository.getAllCourses()) {
                                    if (C.getCourseID() == courseToDelete) {
                                        if (repository.getAssociatedAssessments(courseToDelete).isEmpty()) {
                                            repository.delete(C);
                                            System.out.println("Course Deleted");
                                            View view = findViewById(R.id.termDetailTermTitle);
                                            Snackbar.make(view, "Course Deleted", Snackbar.LENGTH_LONG).setAnchorView(editCourseID).show();
                                        } else {
                                            System.out.println("There are Associated Courses");
                                            View view = findViewById(R.id.termDetailTermTitle);
                                            Snackbar.make(view, "Must Delete Associated Courses", Snackbar.LENGTH_LONG).setAnchorView(editCourseID).show();
                                        }

                                    }
                                }
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                                System.out.println("Cancel delete");
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
                return true;

            case R.id.course_notify_start:
                String id = editCourseID.getText().toString();
                String title = editCourseTitle.getText().toString();
                Intent intent = new Intent(CourseDetail.this, MyReceiver.class);
                intent.putExtra("alarmMessage", "Course: " + id + " " + title + " starts today!");
                PendingIntent sender = PendingIntent.getBroadcast(CourseDetail.this, ++Home.numAlert, intent, 0);
                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

                String startDate = editCourseStart.getText().toString();
                String dateFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);
                Date dateStart = null;
                System.out.println(startDate);
                try {
                    dateStart = sdf.parse(startDate);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Long triggerStart = dateStart.getTime();
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerStart, sender);

                return true;

            case R.id.course_notify_end:
                id = editCourseID.getText().toString();
                title = editCourseTitle.getText().toString();
                Intent intentE = new Intent(CourseDetail.this, MyReceiver.class);
                intentE.putExtra("alarmMessage", "Course: " + id + " " + title + " ends today!");
                PendingIntent senderE = PendingIntent.getBroadcast(CourseDetail.this, ++Home.numAlert, intentE, 0);
                AlarmManager alarmManagerE = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

                String newEnd1 = editCourseEnd.getText().toString();
                dateFormat = "MM/dd/yy";
                sdf = new SimpleDateFormat(dateFormat, Locale.US);
                Date newEnd = null;
                try {
                    newEnd = sdf.parse(newEnd1);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Long triggerEnd = newEnd.getTime();
                alarmManagerE.set(AlarmManager.RTC_WAKEUP, triggerEnd, senderE);

                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void goToAssessmentList(View view) {
        Intent intent = new Intent(CourseDetail.this, AssessmentList.class );
        startActivity(intent);
    }

    public void goToHome(View view) {
        Intent intent = new Intent(CourseDetail.this, Home.class );
        startActivity(intent);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.finish();
    }


//END OF COURSE DETAIL PAGE

}