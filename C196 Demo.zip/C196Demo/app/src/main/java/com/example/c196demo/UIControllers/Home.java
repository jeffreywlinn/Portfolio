package com.example.c196demo.UIControllers;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.c196demo.Database.Repository;
import com.example.c196demo.Entities.Assessments;
import com.example.c196demo.Entities.Courses;
import com.example.c196demo.Entities.Terms;
import com.example.c196demo.R;

public class Home extends AppCompatActivity {

    public static int numAlert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        Repository repository = new Repository(getApplication());
        Terms term1 = new Terms(1,"01-01-2022", "01-31-2022", "First Term");
        repository.insert(term1);
        repository.update(term1);
        Terms term2 = new Terms(2,"01-01-2022", "01-31-2022", "2nd Term");
        repository.insert(term2);
        repository.update(term2);
        Terms term3 = new Terms(3,"01-01-2022", "01-31-2022", "3rd Term");
        repository.insert(term3);
        repository.update(term3);
        Terms term4 = new Terms(4,"01-01-2022", "01-31-2022", "4th Term");
        repository.insert(term4);
        repository.update(term4);

        Courses course1 = new Courses(1, 1, "course1", "01-01-2022", "01-01-2022", "In Progress",
                "John Smith", "800-555-1234", "johnsmith@gmail.com", "This is my message");
        repository.insert(course1);
        repository.update(course1);
        Courses course2 = new Courses(2, 2, "course2", "01-01-2022", "01-01-2022", "In Progress",
                "John Smith", "800-555-1234", "johnsmith@gmail.com", "This is my message");
        repository.insert(course2);
        repository.update(course2);
        Courses course3 = new Courses(3, 3, "course3", "01-01-2022", "01-01-2022", "In Progress",
                "John Smith", "800-555-1234", "johnsmith@gmail.com", "This is my message");
        repository.insert(course3);
        repository.update(course3);
        Courses course4 = new Courses(4, 4, "course4", "01-01-2022", "01-01-2022", "In Progress",
                "John Smith", "800-555-1234", "johnsmith@gmail.com", "This is my message");
        repository.insert(course4);
        repository.update(course4);

        Assessments assessment1 = new Assessments(1, 1, "Performance", "assessment1", "10-31-2022", "1-31-2022");
        repository.insert(assessment1);
        repository.update(assessment1);
        Assessments assessment2 = new Assessments(2, 2, "Objective", "assessment2", "10-31-2022", "1-31-2022");
        repository.insert(assessment2);
        repository.update(assessment2);
        Assessments assessment3 = new Assessments(3, 3, "Performance", "assessment3", "10-31-2022", "1-31-2022");
        repository.insert(assessment3);
        repository.update(assessment3);
        Assessments assessment4 = new Assessments(4, 4, "Objective", "assessment4", "10-31-2022", "1-31-2022");
        repository.insert(assessment4);
        repository.update(assessment4);
    }

    /**This is the method with Intent to go to ProductList page on Enter button*/
    public void goToTermList(View view) {
        Intent intent = new Intent(Home.this, TermList.class);
        startActivity(intent);
        System.out.println("Clicked to Term List");

    }
    /**This is the method with Intent to go to ProductList page on Enter button*/
    public void goToCourseList(View view) {
        Intent intent = new Intent(Home.this, CourseList.class);
        startActivity(intent);
        System.out.println("Clicked to Course List");

    }
    /**This is the method with Intent to go to ProductList page on Enter button*/
    public void goToAssessmentList(View view) {
        Intent intent = new Intent(Home.this, AssessmentList.class);
        startActivity(intent);
        System.out.println("Clicked to Assessment List");

    }




    // END OF HOME PAGE
}