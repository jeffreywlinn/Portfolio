package com.example.c196demo.UIControllers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.c196demo.Adapters.TermListAdapter;
import com.example.c196demo.Database.Repository;
import com.example.c196demo.Entities.Terms;
import com.example.c196demo.R;

import java.util.List;

public class TermList extends AppCompatActivity {

    private Repository repository;
    String termTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        repository = new Repository(getApplication());
        termTitle = getIntent().getStringExtra("title");

        List<Terms> allTerms = repository.getAllTerms();
        RecyclerView recyclerView = findViewById(R.id.termListRecycler);
        final TermListAdapter termListAdapter = new TermListAdapter(this);
        recyclerView.setAdapter(termListAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        termListAdapter.setTerms(allTerms);

    }
    /**This adds items to the action bar*/
    public boolean onCreateOptionsMenu(Menu menu) {
            getMenuInflater().inflate(R.menu.menu_term_list, menu);
            return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
                case android.R.id.home:
                    this.finish();
                    return true;

            case R.id.term_list_refresh:
                    repository = new Repository(getApplication());
                    List<Terms> allTerms = repository.getAllTerms();
                    RecyclerView recyclerView = findViewById(R.id.termListRecycler);
                    final TermListAdapter termListAdapter = new TermListAdapter(this);
                    recyclerView.setAdapter(termListAdapter);
                    recyclerView.setLayoutManager(new LinearLayoutManager(this));
                    termListAdapter.setTerms(allTerms);
                    return true;

                case R.id.term_list_add:
                    Intent intent = new Intent(TermList.this, TermDetail.class );
                    startActivity(intent);
                    return true;

                    default:
                    return super.onOptionsItemSelected(item);
            }
    }

    /**This method takes user to Home page on button click*/
    public void goToHome(View view) {
        Intent intent = new Intent(TermList.this, Home.class );
        startActivity(intent);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }




// END OF TERM LIST CLASS

}




