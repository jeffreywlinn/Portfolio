package com.example.c196demo.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.c196demo.Entities.Terms;
import com.example.c196demo.R;
import com.example.c196demo.UIControllers.CourseList;
import com.example.c196demo.UIControllers.TermDetail;

import java.util.List;

public class TermListAdapter extends RecyclerView.Adapter<TermListAdapter.TLViewHolder> {


    class TLViewHolder extends RecyclerView.ViewHolder{
        private final TextView termListTermID;
        private final TextView termListTermTitle;
        private final TextView termListStart;
        private final TextView termListEnd;

        /**These are matching to the Term List recycler items*/
        private TLViewHolder(View itemView) {
            super(itemView);
            termListTermID = itemView.findViewById(R.id.termListTermID);
            termListTermTitle = itemView.findViewById(R.id.termListTermTitle);
            termListStart = itemView.findViewById(R.id.termStartDate);
            termListEnd = itemView.findViewById(R.id.termEndDate);

            itemView.setOnClickListener(new View.OnClickListener() {

                /**These are matching to the Term Detail recycler items, and are called by Term Detail Class*/
                @Override
                public void onClick(View view) {
                    System.out.println("Clicked Term List Adapter to Term Details");
                    int position = getAdapterPosition();
                    final Terms current = rTerms.get(position);
                    Intent intent = new Intent(context, TermDetail.class);
                    intent.putExtra("termListTermID", Integer.toString(current.getTermID()));
                    intent.putExtra("termListTermTitle", current.getTermTitle());
                    intent.putExtra("termListTermStart", current.getTermStartDate());
                    intent.putExtra("termListTermEnd", current.getTermEndDate());

                    context.startActivity(intent);

                }
            });
        }
    }
    private LayoutInflater rInflater;
    private Context context;
    private List<Terms> rTerms;

    public TermListAdapter(Context context) {
        rInflater = LayoutInflater.from(context);
        this.context = context;
    }


    @NonNull
    @Override
    public TLViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    View itemView = rInflater.inflate(R.layout.term_list_item, parent, false);

    return new TLViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TLViewHolder holder, int position) {
        if(rTerms != null) {
            Terms current = rTerms.get(position);
            String termTitle = current.getTermTitle();
            String termID = Integer.toString(current.getTermID());
            String termStart = current.getTermStartDate();
            String termEnd = current.getTermEndDate();

            holder.termListTermID.setText(termID);
            holder.termListTermTitle.setText(termTitle);
            holder.termListStart.setText(termStart);
            holder.termListEnd.setText(termEnd);
        } else {
            holder.termListTermID.setText("None");
            holder.termListTermTitle.setText("None");
        }

    }

    public void setTerms(List<Terms> terms) {
        rTerms = terms;
        notifyDataSetChanged();
    }
    @Override
    public int getItemCount() {
        return rTerms.size();
    }


}
