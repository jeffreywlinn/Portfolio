package com.example.c196demo.Utility;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.appcompat.app.AlertDialog;
import com.example.c196demo.R;


public class EditAssessmentDialog extends DialogFragment {

    public interface onEditAssessmentListener {
        void onAssessmentSelectClick(int i);
    }
    private onEditAssessmentListener assessmentSelectedListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setTitle(R.string.edit_assessment);
        builder.setItems(R.array.assessment_list_array, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                assessmentSelectedListener.onAssessmentSelectClick(i);
            }
        });
        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        assessmentSelectedListener = (onEditAssessmentListener) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        assessmentSelectedListener = null;
    }

    // END OF LIST DIALOG CLASS
}