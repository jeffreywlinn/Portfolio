package com.example.c196demo.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.c196demo.Entities.Assessments;
import com.example.c196demo.Entities.Courses;
import com.example.c196demo.R;
import com.example.c196demo.UIControllers.AssessmentDetail;
import com.example.c196demo.UIControllers.CourseDetail;

import java.util.List;

public class AssessmentListAdapter extends RecyclerView.Adapter<AssessmentListAdapter.ALViewHolder> {
    private List<Assessments> aAssessments;
    private final Context context;
    private final LayoutInflater rInflater;

    class ALViewHolder extends RecyclerView.ViewHolder {
        private final TextView assessmentTitle;
        private final TextView assessmentType;

        private ALViewHolder(View itemView) {
            super(itemView);
            assessmentTitle = itemView.findViewById(R.id.assessmentTitle);
            assessmentType = itemView.findViewById(R.id.assessmentType);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    System.out.println("Clicked Assessment List Adapter");
                    int position = getAdapterPosition();
                    final Assessments current = aAssessments.get(position);
                    Intent intent = new Intent(context, AssessmentDetail.class);
                    intent.putExtra("assessmentStart", current.getAssessmentStartDate());
                    intent.putExtra("assessmentEnd", current.getAssessmentEndDate());
                    intent.putExtra("assessmentTitle", current.getAssessmentTitle());
                    intent.putExtra("assessmentType", current.getAssessmentType());
                    intent.putExtra("assessmentID", Integer.toString(current.getAssessmentID()));
                    intent.putExtra("assessmentCourseID", Integer.toString(current.getCourseID()));
                    context.startActivity(intent);
                }
            });
        }
    }


    public AssessmentListAdapter(Context context){
        rInflater = LayoutInflater.from(context);
        this.context=context;
    }

    @NonNull
    @Override
    public AssessmentListAdapter.ALViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = rInflater.inflate(R.layout.assessment_list_item,parent,false);
        return new AssessmentListAdapter.ALViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull AssessmentListAdapter.ALViewHolder holder, int position) {
        if(aAssessments!=null){
            Assessments current = aAssessments.get(position);
            String title = current.getAssessmentTitle();
            String type = current.getAssessmentType();
            holder.assessmentTitle.setText(title);
            holder.assessmentType.setText(type);

        }
        else{
            holder.assessmentTitle.setText("No course name");

        }
    }

    public void setAssessments(List<Assessments> assessments){
        aAssessments = assessments;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return aAssessments.size();
    }

}
