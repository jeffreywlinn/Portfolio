package com.example.c196demo.Database;

import android.app.Application;

import com.example.c196demo.DAO.AssessmentDAO;
import com.example.c196demo.DAO.CourseDAO;
import com.example.c196demo.DAO.TermDAO;
import com.example.c196demo.Entities.Assessments;
import com.example.c196demo.Entities.Courses;
import com.example.c196demo.Entities.Terms;
import com.example.c196demo.UIControllers.TermDetail;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Repository {

    private CourseDAO rCourseDAO;
    private TermDAO rTermDAO;
    private AssessmentDAO rAssessmentDAO;

    private List<Courses> rAllCourses;
    private List<Assessments> rAllAssessments;
    private List<Terms> rAllTerms;

    private static int NUMBER_OF_THREADS = 4;
    static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    /**Repository constructor*/
    public Repository(Application application) {
        DatabaseBuilder db = DatabaseBuilder.getDatabase(application);
        rCourseDAO = db.courseDAO();
        rTermDAO = db.termDAO();
        rAssessmentDAO = db.assessmentDAO();
    }

    private List<Courses> rAssociatedCourses;
    public List<Courses> getAssociatedCourses(int termID) {
       databaseWriteExecutor.execute(() -> {
            rAssociatedCourses = rCourseDAO.getAssociatedCourses(termID);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return rAssociatedCourses;
    }

    private List<Assessments> rAssociatedAssessments;
    public List<Assessments> getAssociatedAssessments(int courseID) {
        databaseWriteExecutor.execute(() -> {
           rAssociatedAssessments = rAssessmentDAO.getAssociatedAssessments(courseID);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return rAssociatedAssessments;
    }

    public List<Terms> getAllTerms() {
        databaseWriteExecutor.execute(() -> {
            rAllTerms = rTermDAO.getAllTerms();
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return rAllTerms;
    }

    public List<Courses> getAllCourses() {
        databaseWriteExecutor.execute(() -> {
            rAllCourses = rCourseDAO.getAllCourses();
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return rAllCourses;
    }

    public List<Assessments> getAllAssessments() {
        databaseWriteExecutor.execute(() -> {
            rAllAssessments = rAssessmentDAO.getAllAssessments();
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return rAllAssessments;
    }


    public void insert(Terms terms) {
        databaseWriteExecutor.execute(() -> {
            rTermDAO.insert(terms);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void insert(Courses courses) {
        databaseWriteExecutor.execute(() -> {
            rCourseDAO.insert(courses);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void insert(Assessments assessments) {
        databaseWriteExecutor.execute(() -> {
            rAssessmentDAO.insert(assessments);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void update(Terms terms) {
        databaseWriteExecutor.execute(() -> {
            rTermDAO.update(terms);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void update(Courses courses) {
        databaseWriteExecutor.execute(() -> {
            rCourseDAO.update(courses);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void update(Assessments assessments) {
        databaseWriteExecutor.execute(() -> {
            rAssessmentDAO.update(assessments);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void delete(Terms terms) {
        databaseWriteExecutor.execute(() -> {
            rTermDAO.delete(terms);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void delete(Courses courses) {
        databaseWriteExecutor.execute(() -> {
            rCourseDAO.delete(courses);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void delete(Assessments assessments) {
        databaseWriteExecutor.execute(() -> {
            rAssessmentDAO.delete(assessments);
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }






    //END OF DB COURSE CLASS
}
