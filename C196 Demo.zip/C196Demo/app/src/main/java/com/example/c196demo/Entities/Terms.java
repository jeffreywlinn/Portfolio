package com.example.c196demo.Entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "term_table")
public class Terms {

    /**Term Variables*/
    @PrimaryKey(autoGenerate = true)
    private int termID;

    private String termStartDate;
    private String termEndDate;
    private String termTitle;

    @Override
    public String toString() {
        return "TermEntity{" +
                "termID=" + termID +
                ", termStartDate=" + termStartDate +
                ", termEndDate=" + termEndDate +
                ", termTitle='" + termTitle + '\'' +
                '}';
    }

    /**Term Constructor*/
    public Terms(int termID, String termStartDate, String termEndDate, String termTitle) {
        this.termID = termID;
        this.termStartDate = termStartDate;
        this.termEndDate = termEndDate;
        this.termTitle = termTitle;
    }


    /**Term getters and setters*/
    public int getTermID() {
        return termID;
    }

    public void setTermID(int termID) {
        this.termID = termID;
    }

    public String getTermStartDate() {
        return termStartDate;
    }

    public void setTermStartDate(String termStartDate) {
        this.termStartDate = termStartDate;
    }

    public String getTermEndDate() {
        return termEndDate;
    }

    public void setTermEndDate(String termEndDate) {
        this.termEndDate = termEndDate;
    }

    public String getTermTitle() {
        return termTitle;
    }

    public void setTermTitle(String termTitle) {
        this.termTitle = termTitle;
    }





    //END OF TERM CLASS
}
