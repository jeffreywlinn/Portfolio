package com.example.c196demo.Utility;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.example.c196demo.R;
import com.example.c196demo.UIControllers.TermDetail;

public class DeleteTermDialog extends DialogFragment {
/*
    public interface onDeleteTermListener {
        public void onPositiveClick(DialogFragment positiveFrag);
        public void onNegativeClick(DialogFragment negativeFrag);

    }

    onDeleteTermListener deleteTermListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Delete Term?");
        builder.setMessage("Are you sure?");
        DialogInterface.OnClickListener dialogListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                switch(i) {
                    case DialogInterface.BUTTON_POSITIVE:
                        System.out.println("Positive");
                        break;
                    case DialogInterface.BUTTON_NEUTRAL:
                        System.out.println("Negative");
                        break;
                }

            }
        };
        builder.setPositiveButton("Yes", dialogListener);
        builder.setNegativeButton("No", dialogListener);
        AlertDialog dialog = builder.create();

        return dialog;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            deleteTermListener = (onDeleteTermListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " must implement OnDeleteTermListener");
        }

    }

    @Override
    public void onDetach() {
        super.onDetach();
        deleteTermListener = null;
    }


 */
}
