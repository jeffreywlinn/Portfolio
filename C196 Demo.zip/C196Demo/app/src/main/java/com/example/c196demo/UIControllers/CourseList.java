package com.example.c196demo.UIControllers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.c196demo.Adapters.CourseListAdapter;
import com.example.c196demo.Database.Repository;
import com.example.c196demo.Entities.Courses;
import com.example.c196demo.R;
import com.example.c196demo.Utility.EditCourseDialog;

import java.util.List;


public class CourseList extends AppCompatActivity implements EditCourseDialog.onEditCourseListener {

    Repository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        repository = new Repository(getApplication());

        /**This shows the full list of courses */
        List<Courses> allCourses = repository.getAllCourses();
        RecyclerView recyclerView = findViewById(R.id.courseRecyclerView);
        final CourseListAdapter courseListAdapter = new CourseListAdapter(this);
        courseListAdapter.setCourses(allCourses);
        recyclerView.setAdapter(courseListAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    /**This adds items to the action bar*/
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_course_list, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            case R.id.course_list_refresh:
                repository = new Repository(getApplication());
                List<Courses> allCourses = repository.getAllCourses();
                RecyclerView recyclerView = findViewById(R.id.courseRecyclerView);
                final CourseListAdapter courseListAdapter = new CourseListAdapter(this);
                recyclerView.setAdapter(courseListAdapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                courseListAdapter.setCourses(allCourses);
                return true;


            case R.id.course_list_add:
                Intent intent = new Intent(CourseList.this, CourseDetail.class );
                startActivity(intent);

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onCourseSelectClick(int i) {

    }


    /**This method takes user to Term Detail page on button click*/
    public void goToHome(View view) {
        Intent intent = new Intent(CourseList.this, Home.class );
        startActivity(intent);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.finish();
    }


// END OF COURSE LIST CLASS

}
