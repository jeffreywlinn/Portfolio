package com.example.c196demo.UIControllers;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.example.c196demo.Adapters.AssessmentListAdapter;
import com.example.c196demo.Database.Repository;
import com.example.c196demo.Entities.Assessments;
import com.example.c196demo.R;
import com.example.c196demo.Utility.EditAssessmentDialog;

import java.util.List;


public class AssessmentList extends AppCompatActivity implements EditAssessmentDialog.onEditAssessmentListener {

    Repository repository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessments_list);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        repository = new Repository(getApplication());

        List<Assessments> allAssessments = repository.getAllAssessments();
        RecyclerView recyclerView = findViewById(R.id.assessmentRecyclerView);
        final AssessmentListAdapter assessmentListAdapter = new AssessmentListAdapter(this);
        assessmentListAdapter.setAssessments(allAssessments);
        recyclerView.setAdapter(assessmentListAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


    }

    /**This adds items to the action bar*/
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_assessment_list, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;

            case R.id.assessment_list_refresh:
                repository = new Repository(getApplication());
                List<Assessments> allAssessments = repository.getAllAssessments();
                RecyclerView recyclerView = findViewById(R.id.assessmentRecyclerView);
                final AssessmentListAdapter assessmentListAdapter = new AssessmentListAdapter(this);
                recyclerView.setAdapter(assessmentListAdapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                assessmentListAdapter.setAssessments(allAssessments);
                return true;

            case R.id.assessment_list_add:
                Intent intent = new Intent(AssessmentList.this, AssessmentDetail.class );
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onAssessmentSelectClick(int i) {

    }

    /**This method takes user to Home page on button click*/
    public void goToHome(View view) {
        Intent intent = new Intent(AssessmentList.this, Home.class );
        startActivity(intent);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.finish();
    }


// END OF COURSE LIST CLASS

}