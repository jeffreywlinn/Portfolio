package com.example.c196demo.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.c196demo.Entities.Courses;
import com.example.c196demo.R;
import com.example.c196demo.UIControllers.CourseDetail;

import java.util.List;

public class CourseListAdapter extends RecyclerView.Adapter<CourseListAdapter.CLViewHolder> {

    class CLViewHolder extends RecyclerView.ViewHolder {
        private final TextView courseTitle;
        private final TextView courseTermID;
        private final TextView courseID;
        private final TextView courseStatus;


        private CLViewHolder(View itemView) {
            super(itemView);
            courseTermID = itemView.findViewById(R.id.courseListTermID);
            courseTitle = itemView.findViewById(R.id.courseListTitle);
            courseID = itemView.findViewById(R.id.courseListID);
            courseStatus = itemView.findViewById(R.id.courseListStatus);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    System.out.println("Clicked Course List Adapter");
                    int position = getAdapterPosition();
                    final Courses current = aCourses.get(position);
                    Intent intent = new Intent(context, CourseDetail.class);
                    intent.putExtra("termDetailCourseID", Integer.toString(current.getCourseID()));
                    intent.putExtra("termDetailCourseTitle", current.getCourseTitle());
                    intent.putExtra("termDetailCourseStatus", current.getCourseStatus());
                    intent.putExtra("termDetailTermID", Integer.toString(current.getTermID()));
                    intent.putExtra("termDetailCourseStart", current.getCourseStartDate());
                    intent.putExtra("termDetailCourseEnd", current.getCourseEndDate());
                    intent.putExtra("termDetailCourseInstructor", current.getCourseInstructorName());
                    intent.putExtra("termDetailInstructorEmail", current.getCourseInstructorEmail());
                    intent.putExtra("termDetailInstructorPhone", current.getCourseInstructorPhone());
                    intent.putExtra("termDetailNote", current.getCourseNote());
                    context.startActivity(intent);
                }
            });
        }
    }
        private List<Courses> aCourses;
        private final Context context;
        private final LayoutInflater aInflater;

    public CourseListAdapter(Context context){
        aInflater = LayoutInflater.from(context);
        this.context=context;
    }

    @NonNull
    @Override
    public CLViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = aInflater.inflate(R.layout.course_list_item,parent,false);
        return new CLViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CLViewHolder holder, int position) {
        if(aCourses!=null){
            Courses current = aCourses.get(position);
            String title = current.getCourseTitle();
            String termID = Integer.toString(current.getTermID());
            String courseID = Integer.toString(current.getCourseID());
            String courseStatus = current.getCourseStatus();

            holder.courseTitle.setText(title);
            holder.courseTermID.setText(termID);
            holder.courseID.setText(courseID);
            holder.courseStatus.setText(courseStatus);

        }
        else{
            holder.courseTitle.setText("No course name");
            holder.courseTermID.setText("No term id");
        }
    }

    public void setCourses(List<Courses> courses){
        aCourses = courses;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return aCourses.size();
    }


    //END OF COURSE ADAPTER
}

