package com.example.c196demo.DAO;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.c196demo.Entities.Assessments;
import com.example.c196demo.Entities.Courses;

import java.util.ArrayList;
import java.util.List;

@Dao
public interface AssessmentDAO {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Assessments assessment);

    @Update
    void update(Assessments assessment);

    @Delete
    void delete(Assessments assessment);

    @Query("DELETE FROM assessment_table")
    void deleteAllAssessments();

    @Query("SELECT * FROM assessment_table")
    List<Assessments> getAllAssessments();

    @Query("SELECT * FROM assessment_table WHERE courseID = :courseID")
    List<Assessments> getAssociatedAssessments(int courseID);

}
