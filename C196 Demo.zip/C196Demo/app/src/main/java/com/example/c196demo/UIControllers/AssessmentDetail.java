package com.example.c196demo.UIControllers;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.c196demo.Adapters.CourseDetailAdapter;
import com.example.c196demo.Database.Repository;
import com.example.c196demo.Entities.Assessments;
import com.example.c196demo.Entities.Courses;
import com.example.c196demo.Entities.Terms;
import com.example.c196demo.R;
import com.google.android.material.snackbar.Snackbar;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AssessmentDetail extends AppCompatActivity {

    private Repository repository;
    public static int numAlert;

    RadioButton editPerformance;
    RadioButton editObjective;
    boolean performance = false;
    boolean objective = false;

    EditText editAssessmentID;
    String assessmentID;
    EditText editAssessmentCourseID;
    String assessmentCourseID;
    EditText editAssessmentTitle;
    String assessmentTitle;
    EditText editAssessmentStart;
    String assessmentStartDate;
    EditText editAssessmentEnd;
    String assessmentEndDate;
    EditText editAssessmentType;
    String assessmentType;

    Calendar myCalendar = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener calAssessmentStart;
    DatePickerDialog.OnDateSetListener calAssessmentEnd;
    Long dateStart; // date for alarm

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        repository = new Repository(getApplication());

        editPerformance = findViewById(R.id.performance);
        editObjective = findViewById(R.id.objective);

        editAssessmentStart = findViewById(R.id.editTextAssessmentStartDate);
        assessmentStartDate = getIntent().getStringExtra("assessmentStart");
        editAssessmentStart.setText(assessmentStartDate);

        editAssessmentEnd = findViewById(R.id.editTextAssessmentEndDate);
        assessmentEndDate = getIntent().getStringExtra("assessmentEnd");
        editAssessmentEnd.setText(assessmentEndDate);

        editAssessmentTitle = findViewById(R.id.editTextAssessmentTitle);
        assessmentTitle = getIntent().getStringExtra("assessmentTitle");
        editAssessmentTitle.setText(assessmentTitle);

        editAssessmentType = findViewById(R.id.editTextAssessmentType);
        assessmentType = getIntent().getStringExtra("assessmentType");
        editAssessmentType.setText(assessmentType);

        RadioButton objective = findViewById(R.id.objective);
        RadioButton performance = findViewById(R.id.performance);
        RadioGroup radioGroup;
        radioGroup = findViewById(R.id.assessmentTypeGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton radioButton = findViewById(i);
                if(radioButton.isChecked()) {
                    editAssessmentType.setText(radioButton.getText());
                }
            }});

        if(assessmentType!= null && assessmentType.equalsIgnoreCase("Performance") ) { performance.setChecked(true); }
        if(assessmentType!= null && assessmentType.equalsIgnoreCase("Objective")){ objective.setChecked(true); }

        editAssessmentID = findViewById(R.id.editTextAssessmentID);
        assessmentID = getIntent().getStringExtra("assessmentID");
        editAssessmentID.setText(assessmentID);

        editAssessmentCourseID = findViewById(R.id.editTextAssessmentCourseID);
        assessmentCourseID = getIntent().getStringExtra("assessmentCourseID");
        editAssessmentCourseID.setText(assessmentCourseID);

        calAssessmentStart = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelStart();
            }
        };

        editAssessmentStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AssessmentDetail.this, calAssessmentStart, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH))
                        .show();
            }
        });

        calAssessmentEnd = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelEnd();
            }
        };
        editAssessmentEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(AssessmentDetail.this, calAssessmentEnd, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH))
                        .show();
            }
        });
    }

    private void updateLabelStart() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editAssessmentStart.setText(sdf.format(myCalendar.getTime()));
    }
    private void updateLabelEnd() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editAssessmentEnd.setText(sdf.format(myCalendar.getTime()));
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_assessment_detail, menu);
        return true;
    }

    /**This is on Course Detail page second "edit" pencil and does a pop up to SMS*/
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;

            case R.id.assessment_saving:
                    String start = editAssessmentStart.getText().toString();
                    String end = editAssessmentEnd.getText().toString();
                    String assessmentID = editAssessmentID.getText().toString();
                    String assessmentTitle = editAssessmentTitle.getText().toString();
                    String assessmentType = editAssessmentType.getText().toString();
                    String courseID = editAssessmentCourseID.getText().toString();

                    if(start.isEmpty() || end.isEmpty() || assessmentTitle.isEmpty() || assessmentType.isEmpty()) {
                        View view = findViewById(R.id.editTextAssessmentType);
                        Snackbar.make(view, "Incomplete Fields", Snackbar.LENGTH_LONG).setAnchorView(editAssessmentType).show();
                    } else {
                        if(!assessmentID.isEmpty()) {
                            int assessmentIDVal = Integer.parseInt(assessmentID);
                            for(Assessments A : repository.getAllAssessments()) {
                                if(A.getAssessmentID() == assessmentIDVal) {
                                    View view = findViewById(R.id.editTextAssessmentType);
                                    Snackbar.make(view, "AssessmentID already exists. Either leave blank or try a different ID", Snackbar.LENGTH_LONG).setAnchorView(editAssessmentType).show();
                                } else {
                                    if(courseID.isEmpty()) {
                                        int courseIDVal = 0;
                                        int aIDVal = Integer.parseInt(assessmentID);
                                        Assessments newAssessment = new Assessments(aIDVal, courseIDVal, assessmentType, assessmentTitle, end,start );
                                        repository.update(newAssessment);
                                        Intent intent = new Intent(AssessmentDetail.this, AssessmentList.class);
                                        startActivity(intent);
                                    } else {
                                        int courseIDVal = Integer.parseInt(courseID);
                                        int aIDVal = Integer.parseInt(assessmentID);
                                        Assessments newAssessment = new Assessments(aIDVal, courseIDVal, assessmentType, assessmentTitle, end,start );
                                        repository.update(newAssessment);
                                        Intent intent = new Intent(AssessmentDetail.this, AssessmentList.class);
                                        startActivity(intent);
                                    }
                                }
                            }
                        } else {
                            int courseIDVal = 0;
                            int aIDVal = 0;
                            Assessments newAssessment = new Assessments(aIDVal, courseIDVal, assessmentType, assessmentTitle, end,start );
                            repository.insert(newAssessment);
                            Intent intent = new Intent(AssessmentDetail.this, AssessmentList.class);
                            startActivity(intent);
                        }
                    }

                return true;

            case R.id.assessment_delete:
                Integer assessmentToDelete = Integer.parseInt(editAssessmentID.getText().toString());
                for(Assessments A : repository.getAllAssessments()) {
                    if(A.getAssessmentID() == assessmentToDelete) {
                        repository.delete(A);
                        Intent intent = new Intent(AssessmentDetail.this, AssessmentList.class);
                        startActivity(intent);

                    }
                }
                return true;

            case R.id.assessment_notify_start:
                String id = editAssessmentID.getText().toString();
                String type = editAssessmentType.getText().toString();
                Intent intent = new Intent(AssessmentDetail.this, MyReceiver.class);
                intent.putExtra("alarmMessage", "Your assessment " + id + " " + type + " starts today!");
                PendingIntent sender = PendingIntent.getBroadcast(AssessmentDetail.this, ++Home.numAlert, intent, 0);
                AlarmManager alarmManagerStart = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                String startDate = editAssessmentStart.getText().toString();
                String dateFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);
                Date dateStart = null;

                try {
                    dateStart = sdf.parse(startDate);

                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Long triggerStart = dateStart.getTime();

                alarmManagerStart.set(AlarmManager.RTC_WAKEUP, triggerStart, sender);

                return true;

            case R.id.assessment_notify_end:
            id = editAssessmentID.getText().toString();
            type = editAssessmentType.getText().toString();
            Intent intentA = new Intent(AssessmentDetail.this, MyReceiver.class);
            intentA.putExtra("alarmMessage", "Your assessment " + id + " " + type + " ends today!");

            PendingIntent senderE = PendingIntent.getBroadcast(AssessmentDetail.this, ++Home.numAlert, intentA, 0);
            AlarmManager alarmManagerEnd = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

            String endDate = editAssessmentEnd.getText().toString();
            dateFormat = "MM/dd/yy";
            sdf = new SimpleDateFormat(dateFormat, Locale.US);
            Date dateEnd = null;

            try {
                dateEnd = sdf.parse(endDate);

            } catch (ParseException e) {
                e.printStackTrace();
            }
            Long triggerEnd = dateEnd.getTime();
            alarmManagerEnd.set(AlarmManager.RTC_WAKEUP, triggerEnd, senderE);

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void goToAssessmentList(View view) {
        Intent intent = new Intent(AssessmentDetail.this, AssessmentList.class );
        startActivity(intent);
    }

    /**This method takes user to Term Detail page on button click*/
    public void goToHome(View view) {
        Intent intent = new Intent(AssessmentDetail.this, Home.class );
        startActivity(intent);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.finish();
    }

//END OF COURSE DETAIL PAGE

}