package com.example.c196demo.Utility;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.example.c196demo.R;

public class DeleteCourseDialog extends DialogFragment {

    public interface onDeleteCourseListener {
        void onCourseSelectClick(int i);
    }
    private DeleteCourseDialog.onDeleteCourseListener courseSelectedListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setTitle(R.string.edit_course);
        builder.setItems(R.array.course_list_array, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                courseSelectedListener.onCourseSelectClick(i);
            }
        });
        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        courseSelectedListener = (DeleteCourseDialog.onDeleteCourseListener) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        courseSelectedListener = null;
    }
}
