package com.example.c196demo.DAO;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.c196demo.Entities.Terms;

import java.util.List;

@Dao
public interface TermDAO {

        @Insert(onConflict = OnConflictStrategy.IGNORE)
        void insert(Terms term);

        @Update
        void update(Terms term);

        @Delete
        void delete(Terms term);

        @Query("DELETE FROM term_table")
        void deleteAllTerms();

        @Query("SELECT * FROM term_table ")
        List<Terms> getAllTerms();


}
