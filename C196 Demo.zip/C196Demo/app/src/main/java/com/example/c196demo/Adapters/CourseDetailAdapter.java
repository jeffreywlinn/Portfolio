package com.example.c196demo.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.c196demo.Entities.Assessments;
import com.example.c196demo.Entities.Courses;
import com.example.c196demo.Entities.Terms;
import com.example.c196demo.R;
import com.example.c196demo.UIControllers.AssessmentDetail;
import com.example.c196demo.UIControllers.CourseDetail;
import com.example.c196demo.UIControllers.CourseList;

import java.util.List;

public class CourseDetailAdapter extends RecyclerView.Adapter<CourseDetailAdapter.CDViewHolder>{
    private LayoutInflater rInflater;
    private Context context;
    //private List<Courses> rCourses;
    private List<Assessments> rAssessments;

    class CDViewHolder extends RecyclerView.ViewHolder{
        private final TextView assessmentID;
        private final TextView assessmentType;
        private final TextView assessmentEnd;
        private final TextView assessmentStart;

        /**These match the Course Detail recycler items*/
        private CDViewHolder(View itemView) {
            super(itemView);
            assessmentID = itemView.findViewById(R.id.courseAssessmentID);
            assessmentType = itemView.findViewById(R.id.courseAssessmentType);
            assessmentEnd = itemView.findViewById(R.id.courseAssessmentEnd);
            assessmentStart = itemView.findViewById(R.id.courseAssessmentStart);

            itemView.setOnClickListener(new View.OnClickListener() {

                /**These match the Assessment Detail recycler items and are called by Assessment Detail Class*/
                @Override
                public void onClick(View view) {
                    System.out.println("Clicked Course Detail Adapter to Assessment Detail");
                    int position = getAdapterPosition();
                    final Assessments currentA = rAssessments.get(position);
                    Intent intent = new Intent(context, AssessmentDetail.class);
                    intent.putExtra("assessmentID", Integer.toString(currentA.getAssessmentID()));
                    intent.putExtra("assessmentType", currentA.getAssessmentType());
                    intent.putExtra("assessmentEnd", currentA.getAssessmentEndDate());
                    intent.putExtra("assessmentStart", currentA.getAssessmentStartDate());
                    intent.putExtra("assessmentTitle", currentA.getAssessmentTitle());
                    intent.putExtra("assessmentCourseID", Integer.toString(currentA.getCourseID()));

                    context.startActivity(intent);

                }
            });
        }
    }


    public CourseDetailAdapter(Context context) {
        rInflater = LayoutInflater.from(context);
        this.context = context;
    }

    @NonNull
    @Override
    public CourseDetailAdapter.CDViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = rInflater.inflate(R.layout.course_detail_item, parent, false);
        return new CourseDetailAdapter.CDViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseDetailAdapter.CDViewHolder holder, int position) {
        if(rAssessments != null) {
            Assessments current = rAssessments.get(position);
            holder.assessmentID.setText(Integer.toString(current.getAssessmentID()));
            holder.assessmentType.setText(current.getAssessmentType());
            holder.assessmentEnd.setText(current.getAssessmentEndDate());
            holder.assessmentStart.setText(current.getAssessmentStartDate());

        } else {
            holder.assessmentID.setText("None");
            holder.assessmentType.setText("None");
        }

    }

    public void setAssessments(List<Assessments> assessments) {
        rAssessments = assessments;
        notifyDataSetChanged();
    }
    @Override
    public int getItemCount() {
        return rAssessments.size();
    }





}
