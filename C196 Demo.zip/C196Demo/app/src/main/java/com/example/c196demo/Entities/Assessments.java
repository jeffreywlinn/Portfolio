package com.example.c196demo.Entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "assessment_table")

public class Assessments {

    /**Assessment Variables*/
    @PrimaryKey(autoGenerate = true)
    private int assessmentID;
    private int courseID;
    private String assessmentType;
    private String assessmentTitle;
    private String assessmentEndDate;
    private String assessmentStartDate;


    @Override
    public String toString() {
        return "AssessmentEntity{" +
                "assessmentID=" + assessmentID +
                ", assessmentType='" + assessmentType + '\'' +
                ", assessmentTitle='" + assessmentTitle + '\'' +
                ", assessmentEndDate=" + assessmentEndDate +
                '}';
    }

    /**Assessment Constructor*/
    public Assessments(int assessmentID, int courseID, String assessmentType, String assessmentTitle, String assessmentEndDate, String assessmentStartDate) {
        this.assessmentID = assessmentID;
        this.courseID = courseID;
        this.assessmentType = assessmentType;
        this.assessmentTitle = assessmentTitle;
        this.assessmentEndDate = assessmentEndDate;
        this.assessmentStartDate = assessmentStartDate;
    }

    /**Assessment Getters and Setters*/
    public int getAssessmentID() {
        return assessmentID;
    }

    public void setAssessmentID(int assessmentID) {
        this.assessmentID = assessmentID;
    }

    public int getCourseID() { return courseID; }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public String getAssessmentType() {
        return assessmentType;
    }

    public void setAssessmentType(String assessmentType) {
        this.assessmentType = assessmentType;
    }

    public String getAssessmentTitle() {
        return assessmentTitle;
    }

    public void setAssessmentTitle(String assessmentTitle) {
        this.assessmentTitle = assessmentTitle;
    }

    public String getAssessmentEndDate() {
        return assessmentEndDate;
    }

    public void setAssessmentEndDate(String assessmentEndDate) {
        this.assessmentEndDate = assessmentEndDate;
    }

    public String getAssessmentStartDate() { return assessmentStartDate; }

    public void setAssessmentStartDate(String assessmentStartDate) {
        this.assessmentStartDate = assessmentStartDate;
    }

    // END OF ASSESSMENT CLASS
}
