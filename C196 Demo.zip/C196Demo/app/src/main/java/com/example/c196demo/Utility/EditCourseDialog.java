package com.example.c196demo.Utility;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.appcompat.app.AlertDialog;
import com.example.c196demo.R;


public class EditCourseDialog extends DialogFragment {

    public interface onEditCourseListener {
        void onCourseSelectClick(int i);
    }
    private onEditCourseListener courseSelectedListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setTitle(R.string.edit_course);
        builder.setItems(R.array.course_list_array, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                courseSelectedListener.onCourseSelectClick(i);
            }
        });
        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        courseSelectedListener = (onEditCourseListener) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        courseSelectedListener = null;
    }

    // END OF LIST DIALOG CLASS
}