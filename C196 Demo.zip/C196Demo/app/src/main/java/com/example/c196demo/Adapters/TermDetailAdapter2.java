package com.example.c196demo.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.c196demo.DAO.CourseDAO;
import com.example.c196demo.Database.Repository;
import com.example.c196demo.Entities.Assessments;
import com.example.c196demo.Entities.Courses;
import com.example.c196demo.Entities.Terms;
import com.example.c196demo.R;
import com.example.c196demo.UIControllers.CourseDetail;
import com.example.c196demo.UIControllers.CourseList;
import com.example.c196demo.UIControllers.TermDetail;
import com.example.c196demo.UIControllers.TermList;

import java.util.List;

public class TermDetailAdapter2 extends RecyclerView.Adapter<TermDetailAdapter2.TDViewHolder2> {

    private LayoutInflater rInflater;
    private Context context;
    private List<Courses> rCourses;

    class TDViewHolder2 extends RecyclerView.ViewHolder{
        private final TextView courseID;
        private final TextView courseStatus;
        private final TextView courseTitle;

        /**These match the Term Detail recycler items*/
        private TDViewHolder2(View itemView) {
            super(itemView);
            courseID = itemView.findViewById(R.id.termDetailCourseID2);
            courseStatus = itemView.findViewById(R.id.termDetailCourseStatus2);
            courseTitle = itemView.findViewById(R.id.termDetailCourseTitle2);

            itemView.setOnClickListener(new View.OnClickListener() {

                /**These match the Course Detail recycler items and are called by Course Detail Class*/
                @Override
                public void onClick(View view) {
                    System.out.println("Clicked Term Detail Adapter2");
                    int position = getAdapterPosition();
                    final Courses current = rCourses.get(position);
                    Intent intent = new Intent(context, CourseDetail.class);
                    intent.putExtra("termDetailCourseID", Integer.toString(current.getCourseID()));
                    intent.putExtra("termDetailCourseTitle", current.getCourseTitle());
                    intent.putExtra("termDetailCourseStart", current.getCourseStartDate());
                    intent.putExtra("termDetailCourseEnd", current.getCourseEndDate());
                    intent.putExtra("termDetailTermID", Integer.toString(current.getTermID()));
                    intent.putExtra("termDetailCourseStatus", current.getCourseStatus());
                    intent.putExtra("termDetailCourseInstructor", current.getCourseInstructorName());
                    intent.putExtra("termDetailInstructorEmail", current.getCourseInstructorEmail());
                    intent.putExtra("termDetailInstructorPhone", current.getCourseInstructorPhone());
                    intent.putExtra("termDetailNote", current.getCourseNote());

                    context.startActivity(intent);



                }
            });
        }
    }


    public TermDetailAdapter2(Context context) {
        rInflater = LayoutInflater.from(context);
        this.context = context;
    }


    @NonNull
    @Override
    public TDViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = rInflater.inflate(R.layout.term_detail_item2, parent, false);
        return new TDViewHolder2(itemView);

    }

    @Override
    public void onBindViewHolder(@NonNull TDViewHolder2 holder, int position) {
        if(rCourses != null) {
            Courses current = rCourses.get(position);
            String courseTitle = current.getCourseTitle();
            String courseID = Integer.toString(current.getCourseID());
            String courseStatus = current.getCourseStatus();

            holder.courseID.setText(courseID);
            holder.courseTitle.setText(courseTitle);
            holder.courseStatus.setText(courseStatus);

        } else {
            holder.courseID.setText("None");
            holder.courseTitle.setText("None");
            holder.courseStatus.setText("None");
        }
    }

    public void setTermCourses(List<Courses> courses) {
        rCourses = courses;
        notifyDataSetChanged();
    }
    @Override
    public int getItemCount() {
        if(rCourses == null) {
            return 0;
        }
        return rCourses.size();
    }






}
