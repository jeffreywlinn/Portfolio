package com.example.c196demo.DAO;

import android.database.sqlite.SQLiteDatabase;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.c196demo.Database.DatabaseBuilder;
import com.example.c196demo.Database.Repository;
import com.example.c196demo.Entities.Assessments;
import com.example.c196demo.Entities.Courses;

import java.util.ArrayList;
import java.util.List;

@Dao
public interface CourseDAO {

    SQLiteDatabase db = null;

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Courses course);

    @Update
    void update(Courses course);

    @Delete
    void delete(Courses course);

    @Query("DELETE FROM course_table")
    void deleteAssociatedCourses();

    @Query("SELECT * FROM course_table ")
    List<Courses> getAllCourses();

    @Query("SELECT * FROM course_table WHERE termID = :termID")
    List<Courses> getAssociatedCourses(int termID);



}
