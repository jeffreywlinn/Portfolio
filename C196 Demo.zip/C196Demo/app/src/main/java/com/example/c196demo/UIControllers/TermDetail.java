package com.example.c196demo.UIControllers;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.FragmentManager;

import com.example.c196demo.Adapters.TermDetailAdapter;
import com.example.c196demo.Adapters.TermDetailAdapter2;
import com.example.c196demo.Adapters.TermListAdapter;
import com.example.c196demo.Database.Repository;
import com.example.c196demo.Entities.Courses;
import com.example.c196demo.Entities.Terms;
import com.example.c196demo.R;
import com.example.c196demo.Utility.DeleteTermDialog;
import com.google.android.material.snackbar.Snackbar;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TermDetail extends AppCompatActivity {

    private Repository repository;
    EditText editDate;
    TextView editTermStart;
    String termStart;
    TextView editTermEnd;
    String termEnd;
    TextView editTermTitle;
    String termTitle;
    TextView editTermID ;
    String termID;


    DatePickerDialog.OnDateSetListener calTermStart;
    DatePickerDialog.OnDateSetListener calTermEnd;
    Calendar termCalendar = Calendar.getInstance();

    int numAlert;
    private int mTimerLength;


    /**These match the Term List Adapter OnClick*/
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        repository = new Repository(getApplication());

        editTermStart = findViewById(R.id.termStartDate);
        termStart = getIntent().getStringExtra("termListTermStart");
        editTermStart.setText(termStart);

        editTermEnd = findViewById(R.id.termEndDate);
        termEnd = getIntent().getStringExtra("termListTermEnd");
        editTermEnd.setText(termEnd);

        editTermTitle = findViewById(R.id.termDetailTermTitle);
        termTitle = getIntent().getStringExtra("termListTermTitle");
        editTermTitle.setText(termTitle);

        editTermID = findViewById(R.id.termDetailTermID);
        termID = getIntent().getStringExtra("termListTermID");
        editTermID.setText(termID);

        /**This shows the list of courses in the selected Term*/

        if(!editTermID.getText().toString().isEmpty()) {
            List<Courses> associatedCourses = repository.getAssociatedCourses(Integer.parseInt(termID));
            RecyclerView recyclerView = findViewById(R.id.termCourseListRecycler);
            final TermDetailAdapter termDetailAdapter = new TermDetailAdapter(this);
            termDetailAdapter.setTermCourses(associatedCourses);
            recyclerView.setAdapter(termDetailAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        } else {
            List<Courses> associatedCourses = repository.getAssociatedCourses(0);
            RecyclerView recyclerView = findViewById(R.id.termCourseListRecycler);
            final TermDetailAdapter termDetailAdapter = new TermDetailAdapter(this);
            termDetailAdapter.setTermCourses(associatedCourses);
            recyclerView.setAdapter(termDetailAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
        }
        List<Courses> allcourses2 = repository.getAllCourses();
        RecyclerView recyclerView2 = findViewById(R.id.termCourseListRecycler2);
        final TermDetailAdapter2 termDetailAdapter2 = new TermDetailAdapter2(this);
        termDetailAdapter2.setTermCourses(allcourses2);
        recyclerView2.setAdapter(termDetailAdapter2);
        recyclerView2.setLayoutManager(new LinearLayoutManager(this));



        calTermStart = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                termCalendar.set(Calendar.YEAR, year);
                termCalendar.set(Calendar.MONTH, monthOfYear);
                termCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelStart();
            }
        };
        editTermStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(TermDetail.this, calTermStart, termCalendar
                        .get(Calendar.YEAR), termCalendar.get(Calendar.MONTH), termCalendar.get(Calendar.DAY_OF_MONTH))
                        .show();
            }
        });

        calTermEnd = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                termCalendar.set(Calendar.YEAR, year);
                termCalendar.set(Calendar.MONTH, monthOfYear);
                termCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateLabelEnd();
            }
        };
        editTermEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(TermDetail.this, calTermEnd, termCalendar
                        .get(Calendar.YEAR), termCalendar.get(Calendar.MONTH), termCalendar.get(Calendar.DAY_OF_MONTH))
                        .show();
            }
        });

    }


    private void updateLabelStart() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editTermStart.setText(sdf.format(termCalendar.getTime()));
    }

    private void updateLabelEnd() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        editTermEnd.setText(sdf.format(termCalendar.getTime()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_term_detail, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case android.R.id.home:
                this.finish();
                return true;

            case R.id.term_detail_refresh:
                repository = new Repository(getApplication());
                List<Courses> associatedCourses = repository.getAssociatedCourses(Integer.parseInt(termID));
                RecyclerView recyclerView = findViewById(R.id.termCourseListRecycler);
                final TermDetailAdapter termDetailAdapter = new TermDetailAdapter(this);
                termDetailAdapter.setTermCourses(associatedCourses);
                recyclerView.setAdapter(termDetailAdapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(this));
                return true;

            case R.id.term_saving:
                    String start = editTermStart.getText().toString();
                    String end = editTermEnd.getText().toString();
                    String termTitle = editTermTitle.getText().toString();
                    String termID = editTermID.getText().toString();
                    if(termID.isEmpty()) {
                        editTermID.setText("0");
                        int termIDB = Integer.parseInt(editTermID.getText().toString());
                        Terms newTerm = new Terms(termIDB, start, end, termTitle);
                        repository.insert(newTerm);
                    }
                    if(!termID.isEmpty()) {
                        int termIDC = Integer.parseInt(termID);
                        Terms updateTerm = new Terms(termIDC, start, end, termTitle);
                        repository.update(updateTerm);

                    }
                Intent intentB = new Intent(TermDetail.this, TermList.class);
                startActivity(intentB);
                    return true;

            case R.id.term_add:
                Intent intentC = new Intent(TermDetail.this, CourseDetail.class);

                intentC.putExtra("termDetailTermID", editTermID.getText().toString());

                startActivity(intentC);
                return true;

            case R.id.term_delete:
                int termToDelete = Integer.parseInt(editTermID.getText().toString());
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Delete Term").setMessage("Are you sure?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                for (Terms T : repository.getAllTerms()) {
                                    if (T.getTermID() == termToDelete) {
                                        if (repository.getAssociatedCourses(termToDelete).isEmpty()) {
                                            repository.delete(T);
                                            System.out.println("Term Deleted");
                                        } else {
                                            System.out.println("There are Associated Courses");
                                            View view = findViewById(R.id.termDetailTermTitle);
                                            Snackbar.make(view, "Must Delete Associated Courses", Snackbar.LENGTH_SHORT).setAnchorView(editTermEnd).show();
                                        }

                                    }
                                }
                            }
                        })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                        System.out.println("Cancel delete");
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
                return true;


        }
            return super.onOptionsItemSelected(item);
    }

    public void goToCourseList (View view){
            Intent intent1 = new Intent(TermDetail.this, CourseList.class);
            startActivity(intent1);

        }

    /**This method takes user to Term Detail page on button click*/
    public void goToHome(View view) {
        Intent intent2 = new Intent(TermDetail.this, Home.class );
        startActivity(intent2);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.finish();
    }


    // END OF TERM DETAIL PAGE
}



